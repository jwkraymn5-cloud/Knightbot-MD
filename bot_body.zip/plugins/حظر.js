// 📌 أمر حظر/إلغاء الحظر للمطور فقط
const handler = async (m, { text, conn, usedPrefix, command }) => {

    // رسالة توضيحية لو المستخدم نسيت تكتب الرقم
    const usage = `⚠️ مثال على الاستخدام:\n${usedPrefix + command} 201234567890\nأو رد على رسالة الشخص`;

    // تحديد رقم المستخدم بطريقة مرنة
    let who = m.mentionedJid && m.mentionedJid[0]
        ? m.mentionedJid[0]                  // إذا ذكر الشخص
        : m.quoted
        ? m.quoted.sender                     // إذا رد على رسالة
        : text
        ? text.replace(/[^0-9]/g, '') + '@s.whatsapp.net' // لو كتب الرقم مباشرة
        : null;

    // لو مفيش رقم، يظهر رسالة استخدام صحيحة
    if (!who) return conn.reply(m.chat, usage, m, { mentions: [m.sender] });

    try {
        // تنفيذ الحظر أو إلغاء الحظر
        if (command.toLowerCase() === 'حظر' || command.toLowerCase() === 'block') {
            await conn.updateBlockStatus(who, 'block');
            conn.reply(m.chat, `✅ تم حظر المستخدم @${who.split('@')[0]}`, m, { mentions: [who] });
        } else if (command.toLowerCase() === 'إلغاء_الحظر' || command.toLowerCase() === 'unblock') {
            await conn.updateBlockStatus(who, 'unblock');
            conn.reply(m.chat, `✅ تم إلغاء حظر المستخدم @${who.split('@')[0]}`, m, { mentions: [who] });
        }
    } catch (err) {
        console.error(err);
        conn.reply(m.chat, `❌ حدث خطأ أثناء تنفيذ الأمر. تأكد من الرقم وصلاحيات البوت.`, m);
    }
};

// إعدادات الأمر
handler.help = ["حظر", "إلغاء_الحظر"];
handler.tags = ["المالك"];
handler.command = /^(حظر|إلغاء_الحظر|block|unblock)$/i;
handler.rowner = true; // خاص بالمالك فقط

export default handler;