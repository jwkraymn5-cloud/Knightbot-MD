let handler = async (m) => {
  const reply = ` ____________________________ 
*شغال وعال العال 🐦‍🔥*
::::::::::::::::::💫::::::::::::::::::: `.trim();
  await m.conn.sendMessage(m.chat, {
    text: reply,
    contextInfo: {
      isForwarded: true,
      forwardingScore: 999,
      forwardedNewsletterMessageInfo: {
        newsletterJid: '120363424374998001@newsletter',
        newsletterName: '𝑩𝒐𝒅𝒆 𝑩𝒐𝒐𝒕🦶',
        serverMessageId: 100
      }
    }
  }, { quoted: m });
};

// كلمات مفتاحية للرد التلقائي
handler.customPrefix = /^(|تست|توصت|تيت|ا.تست|||)$/i;
handler.command = new RegExp;
handler.exp = 0;

export default handler;