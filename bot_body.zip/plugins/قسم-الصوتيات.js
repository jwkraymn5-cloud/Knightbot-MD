const handler = async (m, { conn }) => {

    const imageUrl = "https://files.catbox.moe/4v91ll.jpg";

    const messageText = `

*『 مـــرحــبــاً بــك يــا ⌊ ${m.pushName} ⌉ فــي 『 𝐁𝐎𝐓 𝐀𝐁𝐎𝐃 🧠 بــﹻ۬ۦٕ٘۬ـــوت عــۥـ℘ـۥــمطور-بوت 』』*

*⌝ قــســم الــصــوتــيــات ┋🐦‍🔥⌞ ⇊*
*⎔ ⋅ ───━ •﹝🐦‍🔥﹞• ━─── ⋅ ⎔*

🗿┊⇇『 عــمــيــق 』
⛓‍💥┊⇇『 مـنـفـوخ 』
🎐┊⇇『 تــخــيــن 』
⚽┊⇇『 صــاخــب 』
📿┊⇇『 ســريــع 』
📍┊⇇『 تـخـيـنـن 』
🗃️┊⇇『 رفــيــع 』
📬┊⇇『 تـقـطـيـع 』
📕┊⇇『 روبــــوت 』
📆┊⇇『 بــطــيء 』
🗞️┊⇇『 نــاعــم 』
🐿️┊⇇『 سـنـجـاب 』

*⎔ ⋅ ───━ •﹝🐦‍🔥﹞• ━─── ⋅ ⎔*
> 『 𝐁𝐎𝐓 𝐀𝐁𝐎𝐃 🧠 بــﹻ۬ۦٕ٘۬ـــوت عــۥـ℘ـۥــمطور-بـــوت 💗💛 』
`.trim();

    await conn.sendMessage(m.chat, { text: "*✦ جـــارٍ إرســال قــســم الــصــوتــيــات....... 💗📿*" }, { quoted: m });

    await conn.sendMessage(m.chat, {
        image: { url: imageUrl },
        caption: messageText
    }, { quoted: m });

    await conn.sendMessage(m.chat, { react: { text: '🐦‍🔥', key: m.key } });
};

handler.command = /^قسم-الصوتيات$/i;
handler.tags = ["بــودي"];
handler.help = ["بــودي"];

export default handler;