/*
Info pubg id
By: obito mr
channel: https://whatsapp.com/channel/0029Vb6dsyP3rZZgNJUD2F1A
Api: https://obito-mr-apis.vercel.app
*/

import axios from 'axios';

let handler = async (m, { text, command, usedPrefix}) => {
  if (!text || !/^\d+$/.test(text)) {
    return m.reply(`⚠️ يرجى إدخال ID صالح\nمثال: ${usedPrefix + command} 1234567890`);
  }

  try {
    const res = await axios.get(`https://obito-mr-apis.vercel.app/api/info/pubg?id=${text}`);
    const data = res.data;

    if (!data.success || !data.player) {
      return m.reply('❌ لم يتم العثور على معلومات الحساب.');
    }

    const info = data.player.profile_info.basic_info;
    const stats = data.player.profile_info.statistics;

    let reply = `
🎮 *معلومات حساب PUBG:*
━━━━━━━━━━━━━━
👤 *الاسم:* ${info.Nickname}
🆔 *المعرف:* ${info["Player ID"]}
⭐ *المستوى:* ${info.Level}
📍 *المنطقة:* ${info.Region}
❤️ *الإعجابات:* ${info.Likes || "0"}
🎖️ *نقاط الرانك:* ${info["Rank Points"]}
📅 *تاريخ الإنشاء:* ${info["Account Created"] || "غير متوفر"}
🕒 *آخر دخول:* ${info["Last Login"] || "غير متوفر"}
📜 *الوصف:* ${info.Bio || "لا يوجد"}
━━━━━━━━━━━━━━
📊 *إحصائيات اللعب:*
🎮 *المباريات:* ${stats.Matches || 0}
🏆 *الانتصارات:* ${stats.Wins || 0}
🔫 *القتل:* ${stats.Kills || 0}
🎯 *نسبة K/D:* ${stats["K/D Ratio"] || 0}
🔥 *أعلى قتل:* ${stats["Max Kills"] || 0}
💥 *الضرر المتوسط:* ${stats["Average Damage"] || 0}
🚗 *قتل بالمركبة:* ${stats["Vehicle Kills"] || 0}
🎯 *هيدشوت:* ${stats.Headshots || 0}
━━━━━━━━━━━━━━
`;

    m.reply(reply);
  } catch (err) {
    console.error(err);
    m.reply('❌ حدث خطأ أثناء جلب المعلومات، حاول لاحقًا.');
  }
};

handler.help = ['obito_mr_pubg'];
handler.tags = ['obito_mr'];
handler.command = /^(pubg|ببجي|infopubg)$/i;

export default handler;