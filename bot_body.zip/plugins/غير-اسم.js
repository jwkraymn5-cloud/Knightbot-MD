/*
BY : *سكونا*
https://whatsapp.com/channel/0029VbBk7J059PwUGXv60o16
*⎔ ⋅ ───━ •﹝🧞﹞• ━─── ⋅ ⎔*
*/

let handler = async (m, { conn, isAdmin, isBotAdmin, args }) => {
  if (!m.isGroup) return m.reply('*⛔ هذا الأمر يعمل فقط داخل الجروبات.*')
  if (!isAdmin) return m.reply('*🚫 هذا الأمر مخصص للمشرفين فقط.*')
  if (!isBotAdmin) return m.reply('*⚠️ لا أستطيع تغيير اسم الجروب لأنني لست أدمن في الجروب.*')

  // التحقق من كتابة الاسم الجديد
  let newName = args.join(' ')
  if (!newName) return m.reply('✏️ يرجى كتابة الاسم الجديد بعد الأمر.')

  try {
    await m.react('📝') // ايموجي تفاعل

    // تغيير اسم الجروب
    await conn.groupUpdateSubject(m.chat, newName)

    await m.react('✅')
    m.reply(`
*⎔ ⋅ ───━ •﹝⚡﹞• ━─── ⋅ ⎔*
✅ تم تغيير اسم الجروب بنجاح !
📌 الاسم الجديد : *${newName}*
🔰 بواسطة : *${m.pushName}*
*⎔ ⋅ ───━ •﹝🌙 سكونا 🌙﹞• ━─── ⋅ ⎔*
`)

  } catch (e) {
    console.error(e)
    await m.react('❌')
    m.reply('❌ حدث خطأ أثناء محاولة تغيير اسم الجروب، تأكد أن البوت أدمن وحاول مرة أخرى.')
  }
}

handler.help = ['غير-اسم [الاسم الجديد]']
handler.tags = ['group']
handler.command = ['غير-اسم']

export default handler