import yts from 'yt-search';
import axios from "axios";
import { prepareWAMessageMedia, generateWAMessageFromContent } from '@whiskeysockets/baileys';

const handler = async (m, { conn, text, usedPrefix, command }) => {
    if (!text) return conn.sendMessage(
        m.chat,
        { text: `❗ اكتب اسم الأغنية أو رابط يوتيوب\nمثال: ${usedPrefix + command} مروان بابلو` },
        { quoted: m }
    );

    await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

    try {
        let query = text.trim();
        const videoId = extractYouTubeID(query);
        if (videoId) query = `https://www.youtube.com/watch?v=${videoId}`;

        const search = await yts.search(query);
        if (!search.videos.length) throw new Error("لم يتم العثور على نتائج.");
        const video = search.videos[0];

        // تجهيز صورة الفيديو
        const thumbnail = await prepareWAMessageMedia(
            { image: { url: video.thumbnail } },
            { upload: conn.waUploadToServer }
        );

        // نص الرسالة
        const msgText = `
🎵 *نتيجة البحث عن:* ${text}
🎬 *العنوان:* ${video.title}
⏱️ *المدة:* ${video.duration.timestamp || video.duration}
👁️ *المشاهدات:* ${MilesNumber(video.views)}
📺 *القناة:* ${video.author.name}
🔗 *الرابط:* ${video.url}
        `.trim();

        // الرسالة التفاعلية مع الأزرار
        const msg = generateWAMessageFromContent(
            m.chat,
            {
                viewOnceMessage: {
                    message: {
                        interactiveMessage: {
                            body: { text: msgText },
                            footer: { text: '⚡ WHISKY BOT ⚡' },
                            header: { hasMediaAttachment: true, imageMessage: thumbnail.imageMessage },
                            nativeFlowMessage: {
                                buttons: [
                                    { name: 'quick_reply', buttonParamsJson: JSON.stringify({ display_text: '🎧 تحميل الصوت', id: `${usedPrefix}صوت ${video.url}` }) },
                                    { name: 'quick_reply', buttonParamsJson: JSON.stringify({ display_text: '🎥 تحميل الفيديو', id: `${usedPrefix}فيديو ${video.url}` }) }
                                ],
                                messageParamsJson: ""
                            }
                        }
                    }
                }
            },
            { userJid: conn.user.jid, quoted: m }
        );

        await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });

    } catch (e) {
        console.error(e);
        await conn.sendMessage(m.chat, { text: `❌ حدث خطأ أثناء البحث.` }, { quoted: m });
    }
};

// ----- أمر تحميل الصوت باستخدام API مباشر -----
let handlerAudio = async (m, { conn, args }) => {
    if (!args[0]) return conn.sendMessage(m.chat, { text: "🎧 ابعت رابط يوتيوب" }, { quoted: m });

    try {
        await conn.sendMessage(m.chat, { text: "⏳ جاري جلب الصوت..." }, { quoted: m });

        let api = `https://api.akuari.my.id/downloader/youtubeaudio?query=${encodeURIComponent(args[0])}`;
        let res = await axios.get(api);
        let audioUrl = res.data?.url;

        if (!audioUrl) return conn.sendMessage(m.chat, { text: "❌ لم أتمكن من العثور على الصوت." }, { quoted: m });

        await conn.sendMessage(
            m.chat,
            { audio: { url: audioUrl }, mimetype: "audio/mpeg", fileName: "audio.mp3" },
            { quoted: m }
        );

        await conn.sendMessage(m.chat, { text: "✅ تم إرسال الصوت بنجاح." }, { quoted: m });

    } catch (e) {
        console.error(e);
        await conn.sendMessage(m.chat, { text: "❌ حدث خطأ أثناء جلب الصوت، حاول مرة أخرى." }, { quoted: m });
    }
};

// ----- أمر تحميل الفيديو باستخدام API مباشر -----
let handlerVideo = async (m, { conn, args }) => {
    if (!args[0]) return conn.sendMessage(m.chat, { text: "🎥 ابعت رابط يوتيوب" }, { quoted: m });

    try {
        await conn.sendMessage(m.chat, { text: "⏳ جاري جلب الفيديو..." }, { quoted: m });

        let api = `https://api.akuari.my.id/downloader/youtubevideo?query=${encodeURIComponent(args[0])}`;
        let res = await axios.get(api);
        let videoUrl = res.data?.url;

        if (!videoUrl) return conn.sendMessage(m.chat, { text: "❌ لم أتمكن من العثور على الفيديو." }, { quoted: m });

        await conn.sendMessage(
            m.chat,
            { video: { url: videoUrl }, fileName: "video.mp4", caption: '🎬 تم تحميل الفيديو' },
            { quoted: m }
        );

        await conn.sendMessage(m.chat, { text: "✅ تم إرسال الفيديو بنجاح." }, { quoted: m });

    } catch (e) {
        console.error(e);
        await conn.sendMessage(m.chat, { text: "❌ حدث خطأ أثناء جلب الفيديو، حاول مرة أخرى." }, { quoted: m });
    }
};

handler.command = /^(شغل)$/i;
handlerAudio.command = /^(صوت)$/i;
handlerVideo.command = /^(فيديو)$/i;

export default { handler, handlerAudio, handlerVideo };

// ---------- دوال مساعدة ----------
function extractYouTubeID(url) {
    const regex = /(?:youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?)\/|.*[?&]v=)|youtu\.be\/|youtube\.com\/shorts\/)([^"&?\/\s]{11})/;
    const match = url.match(regex);
    return match ? match[1] : null;
}

function MilesNumber(number) {
    return number.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
}