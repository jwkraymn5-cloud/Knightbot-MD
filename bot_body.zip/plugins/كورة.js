import { generateWAMessageFromContent, prepareWAMessageMedia } from '@whiskeysockets/baileys'

const handler = async (m, { conn, usedPrefix }) => {
  const title = '⚽ لعبة الكورة - اختر الإجابة الصحيحة!'
  const thumb = 'https://i.imgur.com/7kG5D6Y.png' // صورة اللعبة

  // اختيارات اللاعب (الأزرار)
  const buttons = [
    { name: 'quick_reply', buttonParamsJson: JSON.stringify({ display_text: '🏃️‍♂️ سدد', id: `${usedPrefix}كورة سدد` }) },
    { name: 'quick_reply', buttonParamsJson: JSON.stringify({ display_text: '🛡️ صد', id: `${usedPrefix}كورة صد` }) },
    { name: 'quick_reply', buttonParamsJson: JSON.stringify({ display_text: '⚡ تمريرة', id: `${usedPrefix}كورة تمريرة` }) },
    { name: 'quick_reply', buttonParamsJson: JSON.stringify({ display_text: '🎯 تسديدة دقيقة', id: `${usedPrefix}كورة تسديدة` }) }
  ]

  const card = {
    body: { text: `🎮 ${title}\n\nاختر حركتك:` },
    footer: { text: '𝐁𝐎𝐓 𝐀𝐁𝐎𝐃 🧠' },
    header: { hasMediaAttachment: true, imageMessage: await prepareWAMessageMedia({ image: { url: thumb } }, { upload: conn.waUploadToServer }) },
    nativeFlowMessage: { buttons, messageParamsJson: '' }
  }

  const msg = generateWAMessageFromContent(m.chat, { viewOnceMessage: { message: { interactiveMessage: card } } }, { quoted: m, userJid: conn.user.jid });
  await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
}

handler.command = /^كورة$/i
export default handler