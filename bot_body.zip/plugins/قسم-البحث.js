import fetch from 'node-fetch';

const handler = async (m, { conn }) => {

  const imageUrl = "https://files.catbox.moe/4v91ll.jpg";

  const messageText = `
*『 مـرحـبـاً بـك يـا ⌊ ${m.pushName} ⌉ فـي بـودي بـ𝐁𝐎𝐓 𝐀𝐁𝐎𝐃 🧠 بــﹻ۬ۦٕ٘۬ـــوت عــۥـ℘ـۥــمطورــوت 🕷️ 』*

*⌝ قـسـم الـبـحـث ┋🔍🕷️⌞ ⇊*
*⎔ ⋅ ───━ •﹝🕷️﹞• ━─── ⋅ ⎔*

📂 ⌈ *.apᴋ* ⌋  
🔎 ⌈ *.جيـتـهـاب* ⌋  
🔎 ⌈ *.تـابـع-شـغـل* ⌋  
🎵 ⌈ *.تـيـك3* ⌋  
📺 ⌈ *.تـيـوبـي* ⌋  
🎶 ⌈ *.شـغـل* ⌋  
🔊 ⌈ *.صـو* ⌋  
🎤 ⌈ *.صـوت* ⌋  
🎧 ⌈ *.صـوتـوي* ⌋  
🖼️ ⌈ *.صـوره* ⌋  
🎙️ ⌈ *.فـويـس* ⌋  
📹 ⌈ *.فـيـد* ⌋  
🎞️ ⌈ *.فـيـديـو* ⌋  
📽️ ⌈ *.فـيـديـوي* ⌋  
📝 ⌈ *.كـلـمـات* ⌋  
🎼 ⌈ *.مـلـف-صـوت* ⌋  
▶️ ⌈ *.يـوتـيـوب* ⌋  

*⎔ ⋅ ───━ •﹝🕷️﹞• ━─── ⋅ ⎔*

> 𝐁𝐎𝐓 𝐀𝐁𝐎𝐃 🧠 بــﹻ۬ۦٕ٘۬ـــوت عــۥـ℘ـۥــمطور🐦‍🔥
  `.trim();

  await conn.sendMessage(m.chat, { text: "*_جـاري إرسـال الـقـسـم....... 💗🕷️_*" }, { quoted: m });

  await conn.sendMessage(m.chat, {
    image: { url: imageUrl },
    caption: messageText
  }, { quoted: m });

  await conn.sendMessage(m.chat, { react: { text: '🕷️', key: m.key } });
};

handler.command = /^قسم-البحث$/i;
handler.tags = ["بحث"];
handler.help = ["قسم-البحث"];

export default handler;