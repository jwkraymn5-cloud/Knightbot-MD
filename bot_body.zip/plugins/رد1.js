let handler = async (m, { conn, args }) => {
  if (/^تست$/i.test(m.text)) {
    await conn.sendMessage(m.chat, {
      text: '*شغال وعال العال 🐦‍🔥*',
      contextInfo: {
        isForwarded: true,
        forwardingScore: 999,
        forwardedNewsletterMessageInfo: {
          newsletterJid: '120363424374998001@newsletter',
          newsletterName: '⛩️ 𝐁𝐎𝐓 𝐀𝐁𝐎𝐃 🧠 بــﹻ۬ۦٕ٘۬ـــوت عــۥـ℘ـۥــمطور BOT 🌴',
          serverMessageId: 100
        },
        externalAdReply: {
          title: '⛩️ 𝐁𝐎𝐓 𝐀𝐁𝐎𝐃 🧠 بــﹻ۬ۦٕ٘۬ـــوت عــۥـ℘ـۥــمطور BOT  🌴',
          body: 'اضغط هنا دعم 𝐁𝐎𝐓 𝐀𝐁𝐎𝐃 🧠 بــﹻ۬ۦٕ٘۬ـــوت عــۥـ℘ـۥــمطور 𝗕𝗢𝗧 ⚔️',
          mediaType: 2,
          thumbnailUrl: 'https://files.catbox.moe/4v91ll.jpg', // ← الصورة المصغّرة
          mediaUrl: 'https://chat.whatsapp.com/DRGLrkSyiH9DXdiRhBoeQy?mode=ems_copy_t',
          showAdAttribution: true,
          renderLargerThumbnail: false // ← اجعلها false لعرضها صغيرة يمين الرسالة
        }
      }
    }, { quoted: m });
    return;
  }
};

handler.customPrefix = /^تست$|^menu$|^allmenu$|^help$/i;
handler.command = new RegExp;
export default handler;