const handler = async (m, { conn }) => {

const imageUrl = "https://files.catbox.moe/4v91ll.jpg";  

const messageText = `

『 مـرحـبـاً بــك يــا ⌊ ${m.pushName} ⌉ فـي 『 𝐁𝐎𝐓 𝐀𝐁𝐎𝐃 🧠 بــﹻ۬ۦٕ٘۬ـــوت عــۥـ℘ـۥــمطور-bₒₜ 』 』

⌝ قــســم الــفــعــالــيــات ┋🪄⌞ ⇊
⎔ ⋅ ───━ •﹝🐦‍🔥﹞• ━─── ⋅ ⎔

📝┊⇇『 احـــزر 』
📍┊⇇『 عــلــم 』
🗃️┊⇇『 عــيــن 』
⚽┊⇇『 كـــورة 』
📿┊⇇『 ديــــن 』
✨┊⇇『 تــرتــيــب 』
🧩┊⇇『 تـفـكـيـك 』
❓┊⇇『 ســؤال 』
💡┊⇇『 إيـمـوجـي 』
🤔┊⇇『 لـغــــز 』
🍥┊⇇『 لـغــز-أنــمـي 』
🏅┊⇇『 ريــاضــة 』
🧠┊⇇『 ثـقـافـي 』

✦─━── •﹝🐦‍🔥﹞• ──━─✦
⟣ ✧ هـذا الـقـسـم قـيـد الـتـطـويـر ✧ ⟢
✦─━── •﹝🐦‍🔥﹞• ──━─✦

✦ 『 𝐁𝐎𝐓 𝐀𝐁𝐎𝐃 🧠 بــﹻ۬ۦٕ٘۬ـــوت عــۥـ℘ـۥــمطور 』ــوت 💗💛
`.trim();

await conn.sendMessage(m.chat, { text: "*✦ جـــارٍ إرســال الـقـسـم....... 💗*" }, { quoted: m });  

await conn.sendMessage(m.chat, {  
    image: { url: imageUrl },  
    caption: messageText  
}, { quoted: m });  

await conn.sendMessage(m.chat, { react: { text: '🐦‍🔥', key: m.key } });

};

handler.command = /^قسم-الفعاليات$/i;
handler.tags = ["بــودي"];
handler.help = ["بــودي"];

export default handler;