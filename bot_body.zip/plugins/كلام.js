// استبدل دالتك الحالية بالدالة التالية
import fetch from "node-fetch";
import cheerio from "cheerio";

/**
 * دالة مساعدة: تجريب lyrics.ovh (يحتاج artist + title)
 */
async function tryLyricsOvh(artist, title) {
  try {
    const url = `https://api.lyrics.ovh/v1/${encodeURIComponent(artist)}/${encodeURIComponent(title)}`;
    const res = await fetch(url);
    if (!res.ok) {
      console.log("lyrics.ovh: non-ok status", res.status);
      return null;
    }
    const json = await res.json();
    if (json && json.lyrics) {
      console.log("lyrics.ovh: found lyrics");
      return json.lyrics;
    }
    console.log("lyrics.ovh: no lyrics in response");
    return null;
  } catch (e) {
    console.log("lyrics.ovh error:", e.message);
    return null;
  }
}

/**
 * دالة: البحث في Genius وجلب أول صفحة أغنية ثم استخراج الكلمات
 */
async function tryGeniusScrape(query) {
  try {
    const searchURL = `https://r.jina.ai/https://genius.com/search?q=${encodeURIComponent(query)}`;
    console.log("Fetching Genius search:", searchURL);
    const searchRes = await fetch(searchURL, {
      headers: {
        "x-return-format": "html",
        "x-engine": "cf-browser-rendering"
      }
    });
    const searchHtml = await searchRes.text();
    const $s = cheerio.load(searchHtml);

    // إيجاد أول رابط يحتوي "-lyrics" أو "/songs/"
    let songHref = null;
    $s('a').each((i, el) => {
      const href = $s(el).attr('href');
      if (!href) return;
      // نبحث عن الأنماط الشائعة
      if (href.includes('-lyrics') || href.includes('/songs/') || /\/[a-z0-9-]+-lyrics/i.test(href)) {
        // تأكد من أنك تختار رابط يقود لصفحة الأغنية
        if (!songHref) songHref = href;
      }
    });

    if (!songHref) {
      // كخيار أخير، نجرب أول رابط يبدأ ب"/"
      const first = $s('a[href^="/"]').first().attr('href');
      if (first) songHref = first;
    }

    if (!songHref) {
      console.log("Genius: no song link found in search page");
      return null;
    }

    // Normalize to absolute URL
    let songURL = songHref.startsWith('http') ? songHref : (songHref.startsWith('/') ? `https://genius.com${songHref}` : `https://genius.com/${songHref}`);
    console.log("Genius: chosen song URL:", songURL);

    // جلب الصفحة عبر jina.ai rendering (لتفادي مشاكل JS)
    const renderedSongURL = `https://r.jina.ai/${songURL}`;
    console.log("Fetching rendered song page:", renderedSongURL);
    const songRes = await fetch(renderedSongURL, {
      headers: {
        "x-return-format": "html",
        "x-engine": "cf-browser-rendering"
      }
    });

    const songHtml = await songRes.text();
    const $ = cheerio.load(songHtml);

    // استخراج كلمات: عناصر حديثة تحمل data-lyrics-container
    let lyrics = "";
    $('[data-lyrics-container="true"]').each((i, el) => {
      lyrics += $(el).text().trim() + "\n";
    });

    // fallback قديم
    if (!lyrics.trim()) {
      const old = $('.lyrics').text();
      if (old && old.trim()) lyrics = old.trim();
    }

    // آخر محاولة: نص المقال أو محتويات عناصر رئيسية
    if (!lyrics.trim()) {
      const possible = $('article, main, [class*="Lyrics__Root"]').text();
      if (possible && possible.trim()) lyrics = possible.trim();
    }

    if (!lyrics.trim()) {
      console.log("Genius: no lyrics extracted from song page");
      return null;
    }

    console.log("Genius: lyrics extracted, length:", lyrics.length);
    return lyrics.trim();
  } catch (e) {
    console.log("Genius scrape error:", e.message);
    return null;
  }
}

/**
 * الدالة الرئيسة: محاولة متعددة المصادر
 */
async function جلب_كلمات_محسنة(الاستعلام) {
  try {
    // جرب فصل "فنان - عنوان" إن المستخدم كتبها بهذا الشكل
    let artist = null, title = null;
    if (الاستعلام.includes(' - ')) {
      [artist, title] = الاستعلام.split(' - ').map(s => s.trim());
    } else if (الاستعلام.includes('-')) {
      const parts = الاستعلام.split('-').map(s => s.trim());
      if (parts.length >= 2) {
        artist = parts[0];
        title = parts.slice(1).join(' - ');
      }
    }

    if (artist && title) {
      console.log(`Trying lyrics.ovh with artist="${artist}" title="${title}"`);
      const ovh = await tryLyricsOvh(artist, title);
      if (ovh) return { source: 'lyrics.ovh', lyrics: ovh };
      console.log("lyrics.ovh didn't find lyrics, moving to Genius");
    } else {
      console.log("No clear artist/title split, will search Genius with query:", الاستعلام);
    }

    // بحث على Genius
    const geniusQuery = (artist && title) ? `${artist} ${title}` : الاستعلام;
    const geniusLyrics = await tryGeniusScrape(geniusQuery);
    if (geniusLyrics) return { source: 'genius', lyrics: geniusLyrics };

    // لو فشل، جرّب مبادلة artist/title أحيانًا يكتبوا بالعكس
    if (artist && title) {
      console.log("Retrying lyrics.ovh swapped (title as artist)");
      const retry = await tryLyricsOvh(title, artist);
      if (retry) return { source: 'lyrics.ovh-swapped', lyrics: retry };
    }

    return null;
  } catch (e) {
    console.log("جلب_كلمات_محسنة error:", e.message);
    return null;
  }
}

/* مثال كيفية استعمالها في الهاندلر (استبدل استدعاء جلب_كلمات) */
const معالج_جديد = async (m, { text, usedPrefix, command }) => {
  if (!text) {
    return m.reply(`طريقة الاستخدام: ${usedPrefix + command} فنان - عنوان\nمثال: ${usedPrefix + command} عمرو دياب - يا ساكنين`);
  }

  await m.reply('🐦‍🔥 *جارٍ البحث عن كلمات الأغنية...*');

  const result = await جلب_كلمات_محسنة(text);

  if (!result) {
    // نطبع أيضًا لوج بسيط للمطور (console)
    console.log("Final: no lyrics found for query:", text);
    return m.reply('🐦‍🔥 *لم يتم العثور على كلمات الأغنية! جرب: "فنان - عنوان" أو اكتب الاسم بالإنجليزية.*');
  }

  // إذا الكلمات طويلة جدًا يمكن إرسال ملف بدل رسالة طويلة (اختياري)
  let reply = `🔎 مصدر: ${result.source}\n\n📄 كلمات الأغنية:\n\n${result.lyrics}`;
  if (reply.length > 6000) {
    // اقتطاع أو تفعيل إرسال ملف .txt (تستطيع تعديل لإرسال ملف)
    reply = `🔎 مصدر: ${result.source}\n\n📄 الكلمات طويلة جدًا — هاعرض بداية الكلمات:\n\n${result.lyrics.slice(0, 6000)}\n\n(اقتباس ابتدائي بسبب حد الرسائل)`;
  }

  return m.reply(reply);
};

export { جلب_كلمات_محسنة, معالج_جديد };