// requestFigureWithImage.js
// وضع الملف في مجلد الأوامر عند البوت
// Usage in group: • رد على صورة في الجروب ب: !طلبمجسم
//                     • أو اكتب: !طلبمجسم 30 PLA تجاري
// FALLBACK_IMAGE: صورة محلية ترسل لو المستخدم لم يرد على صورة

const fs = require('fs');
const path = require('path');

let FALLBACK_IMAGE = path.join(__dirname, 'figure.jpg'); // غيّر لو احتجت مسار آخر

let handler = async (m, { conn, args }) => {
  try {
    // تأكد أنه داخل جروب
    if (!m.isGroup) {
      return await conn.sendMessage(m.chat, { text: '⚠️ هذا الأمر يعمل داخل الجروبات فقط (gp).' }, { quoted: m });
    }

    // قراءة وسائط الوسائط إن كانت في الرد
    let imageBuffer = null;

    // 1) لو المستخدم رد على رسالة تحتوي صورة (m.quoted)
    try {
      if (m.quoted) {
        // حاول تحميل الميديا من الرسالة المقتبسة — دعم لمعظم نسخ Baileys
        // بعض النسخ تستخدم conn.downloadAndSaveMediaMessage or conn.downloadMediaMessage
        if (typeof conn.downloadMediaMessage === 'function') {
          // Baileys (newer)
          const downloaded = await conn.downloadMediaMessage(m.quoted);
          if (downloaded) imageBuffer = downloaded;
        } else if (typeof conn.downloadAndSaveMediaMessage === 'function') {
          // older
          const filePath = await conn.downloadAndSaveMediaMessage(m.quoted, './tmp');
          imageBuffer = fs.readFileSync(filePath);
          // optionally delete tmp file
          try { fs.unlinkSync(filePath); } catch (e) {}
        } else if (m.quoted && m.quoted.download) {
          // some forks attach method to quoted
          imageBuffer = await m.quoted.download();
        }
      }
    } catch (e) {
      console.warn('failed to download quoted media:', e);
      imageBuffer = null;
    }

    // 2) لو ما طلعش صورة من الرد نستخدم صورة محلية كـ fallback
    if (!imageBuffer) {
      if (fs.existsSync(FALLBACK_IMAGE)) {
        imageBuffer = fs.readFileSync(FALLBACK_IMAGE);
      } else {
        // لو مفيش صورة محلية، راسل المستخدم يرفَع صورة
        return await conn.sendMessage(m.chat, { text:
          "⚠️ مافي صورة مرفوعة للطلب.\n• رُد على صورة في الدردشة ثم اكتب `!طلبمجسم`،\nأو ضع ملف صورة باسم `figure.jpg` في مجلد الأوامر كـ fallback." }, { quoted: m });
      }
    }

    // اقرأ المتغيرات من args (ارتفاع، مادة، استخدام)
    const defaults = { heightCm: 25, material: "رزين (SLA)", usage: "شخصي" };
    if (args && args.length) {
      const maybeNum = parseInt(args[0]);
      if (!isNaN(maybeNum)) defaults.heightCm = maybeNum;
      if (args[1]) defaults.material = args[1];
      if (args[2]) defaults.usage = args[2];
    }

    // بناء النص
    const detailedMessage = `مرحبًا 👋،
أريد تصميم/صناعة مجسّم مشابه للصورة المرسلة.

📏 المقاسات:
- ارتفاع نهائي مطلوب: *${defaults.heightCm} سم*.
- قطر القاعدة: حوالي *8-10 سم*.

🧱 المواد:
- مفضّل: *${defaults.material}*.

🎨 الألوان والتشطيب:
- جسم: أخضر/أزرق فاتح.
- هودي/قبعة: أرجواني.
- سلاسل: فضي.
- زجاجة: بنفسجي، كوب أبيض.

🗂️ الملفات المطلوبة للطباعة:
- STL (مقسّم للأجزاء إن لزم) أو OBJ + خرائط UV.
- صور زاوية 360° أو رندرات قبل الطباعة.

⚖️ الاستخدام:
- *${defaults.usage}*

💰 الرجاء تزويدي بتفصيل:
• سعر التصميم (ملف 3D)
• سعر الطباعة لواحد/لعدد
• زمن التصميم
• زمن الطباعة، التشطيب، والشحن

شكرًا — في انتظار النموذج/الـSTL وتقدير التكلفة والوقت.
`;

    // إرسال الصورة مع الكابتشن (النص)
    // دعم طريقتين شائعتين: إرسال buffer مباشرة أو كـ stream/url
    await conn.sendMessage(m.chat, {
      image: imageBuffer,
      caption: detailedMessage
    }, { quoted: m });

    // تأكيد في المجموعة
    await conn.sendMessage(m.chat, { text: "✅ تم نشر طلب المجسّم مع الصورة." }, { quoted: m });

  } catch (err) {
    console.error('requestFigureWithImage error:', err);
    try {
      await conn.sendMessage(m.chat, { text: "❌ حدث خطأ أثناء تنفيذ الأمر. أعد المحاولة أو أرسل لي نوع/نسخة البوت (Baileys/venom/open-wa) لأعدل الكود." }, { quoted: m });
    } catch (e) { console.error(e); }
  }
};

handler.command = /^(طلبمجسم|طلب\-مجسم|طلب\-مجسّم)$/i;
handler.group = true;
module.exports = handler;