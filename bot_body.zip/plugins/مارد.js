/*
كود لعبة المارد الازرق 
by api : obito mr
https://whatsapp.com/channel/0029Vb6dsyP3rZZgNJUD2F1A
*/

import axios from "axios";
import pkg from "@whiskeysockets/baileys";
const { generateWAMessageFromContent, proto, prepareWAMessageMedia} = pkg;

let handler = async function (m, { text, conn}) {
  if (!conn.aki) conn.aki = {};
  const sessionKey = `${m.chat}-${m.sender}`;
  const session = conn.aki[sessionKey];


  if (!text) {
    const buttons = [
      {
        name: "quick_reply",
        buttonParamsJson: JSON.stringify({ display_text: "📘 المساعدة", id: ".مارد المساعدة"}),
},
      {
        name: "quick_reply",
        buttonParamsJson: JSON.stringify({ display_text: "🎮 بدء اللعبة", id: ".مارد ابدا"}),
},
    ];

    const msg = generateWAMessageFromContent(
      m.chat,
      {
        viewOnceMessage: {
          message: {
            interactiveMessage: proto.Message.InteractiveMessage.create({
              body: proto.Message.InteractiveMessage.Body.create({
                text: "🧞‍هل تريد بدء لعبة مارد؟",
}),
              footer: proto.Message.InteractiveMessage.Footer.create({
                text: "اختر احد الخيارات التالية :",
}),
              header: proto.Message.InteractiveMessage.Header.create({
                hasMediaAttachment: false,
                title: "لعبة المارد الازرق..🧞",
}),
              nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                buttons,
}),
}),
},
},
},
      {}
);

    return await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id});
}


  if (text === "المساعدة") {
    return m.reply(`📘 شرح أوامر لعبة مارد :\n\n-.مارد ابدا → بدء اللعبة\n-.مارد نعم / لا / لا أعرف / ربما / ربما لا → إرسال إجابة\n-.مارد رجوع → الرجوع للسؤال السابق\n-.مارد حذف → حذف الجلسة الحالية`);
}


  if (text === "ابدا") {
    try {
      const { data} = await axios.post(`${api_obito}/akinator_start`);
      if (!data.session ||!data.signature) return m.reply(" فشل بدء الجلسة.");

      conn.aki[sessionKey] = {
        session: data.session,
        signature: data.signature,
        step: 0,
        progression: 0,
};

      return sendQuestion(m.chat, data.question, data.akitude_url || null, m);
} catch (err) {
      console.error(err);
      return m.reply("حدث خطأ أثناء بدء اللعبة");
}
}


  if (text === "حذف") {
    if (!session) return m.reply("لا توجد جلسة نشطة");
    delete conn.aki[sessionKey];
    return m.reply("تم حذف الجلسة بنجاح");
}

  
  if (text === "رجوع") {
    if (!session) return m.reply("لا توجد جلسة نشطة");
    try {
      const { data} = await axios.post(`${api_obito}/akinator_back`, {
        session: session.session,
        signature: session.signature,
        step: session.step,
        progression: session.progression,
        cm: "false",
});

      conn.aki[sessionKey].step = data.step;
      conn.aki[sessionKey].progression = data.progression;

      return sendQuestion(m.chat, data.question, data.akitude_url || null, m);
} catch (err) {
      console.error(err);
      return m.reply("لا يمكن الرجوع حالياً");
}
}


  const answers = { "نعم": 0, "لا": 1, "لا أعرف": 2, "ربما": 3, "ربما لا": 4};
  if (answers.hasOwnProperty(text)) {
    if (!session) return m.reply("لا توجد جلسه نشطه حاليا،ابدأ جلسه عبر .مارد ابدا");

    try {
      const { data} = await axios.post(`${api_obito}/akinator_answer`, {
        session: session.session,
        signature: session.signature,
        step: session.step,
        progression: session.progression,
        answer: answers[text],
        cm: "false",
        sid: "NaN",
        question_filter: "string",
});

      if (data.name_proposition) {
        delete conn.aki[sessionKey];
        return conn.sendMessage(
          m.chat,
          {
            image: { url: data.photo},
            caption: `🧞 على ما اضن انك تفكر ب :\n${data.name_proposition}\n${data.description_proposition || "بدون وصف"}`,
},
          { quoted: m}
);
}

      conn.aki[sessionKey].step = data.step;
      conn.aki[sessionKey].progression = data.progression;

      return sendQuestion(m.chat, data.question, data.akitude_url || null, m);
} catch (err) {
      console.error(err);
      return m.reply("حدث خطأ أثناء الإجابة");
}
}


  async function sendQuestion(jid, question, imgUrl, quoted) {
    try {
      let media = null;
      if (imgUrl) {
        media = await prepareWAMessageMedia(
          { image: { url: imgUrl}},
          { upload: conn.waUploadToServer}
);
}

      const caption = `🧞‍مارد \n${question}\n\nاكتب :\n.مارد نعم / لا / لا أعرف / ربما / ربما لا / رجوع / حذف`;

      if (media) {
        return conn.sendMessage(jid, { image: { url: imgUrl}, caption}, { quoted});
} else {
        return conn.sendMessage(jid, { text: caption}, { quoted});
}
} catch (e) {
      console.error(e);
      return conn.sendMessage(jid, { text: question}, { quoted});
}
}
};


const api_obito = "https://mr-obito-api.vercel.app/api";

handler.command = /^مارد$/i;
export default handler;