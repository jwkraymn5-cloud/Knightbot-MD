// ================= قاعدة البيانات =================
const db = {
    // ------------------ مغنين جدد ------------------
    "عصام صاصا": "15 مايو 1994",
    "كابونجا": "10 نوفمبر 1999",
    "مسلم": "28 يوليو 2000",
    "عنبه": "1998",
    "نور التوت": "1996",
    "شواحة": "غير مُعلن",
    "هيفاء وهبي": "10 مارس 1976", // تمت الإضافة

    // ------------------ ممثلين كبار ------------------
    "محمد رمضان": "23 مايو 1988",
    "أحمد حلمي": "18 نوفمبر 1969",
    "أحمد عز": "23 يوليو 1971",
    "أحمد السقا": "1 مارس 1973",
    "أكرم حسني": "10 يوليو 1974",
    "كريم عبد العزيز": "17 أغسطس 1975",
    "أمير كرارة": "10 أكتوبر 1977",
    "ياسر جلال": "19 أبريل 1968",
    "أحمد مكي": "19 يونيو 1978",
    "محمد هنيدي": "1 فبراير 1965",
    "شيكو": "4 سبتمبر 1980",
    "هشام ماجد": "26 أبريل 1979",

    // ------------------ ممثلين جدد ------------------
    "أحمد فلوكس": "22 مارس 1983",
    "آسر ياسين": "14 يناير 1978",
    "هنا الزاهد": "5 يناير 1994",
    "دينا الشربيني": "17 مارس 1985",
    "منة شلبي": "24 يوليو 1982",
    "ياسمين صبري": "21 يناير 1988",
    "مني الشازلي": "غير مُعلن" // تمت الإضافة
};

// ================= دوال مساعدة =================
function getAge(birthDate) {
    if (!birthDate || birthDate === "غير مُعلن") return "غير مُتوفر";

    const parts = birthDate.split(" ");
    if (parts.length < 3) return "غير مُتوفر";

    const months = {
        "يناير": 0, "فبراير": 1, "مارس": 2, "أبريل": 3,
        "مايو": 4, "يونيو": 5, "يوليو": 6, "أغسطس": 7,
        "سبتمبر": 8, "أكتوبر": 9, "نوفمبر": 10, "ديسمبر": 11
    };

    const day = parseInt(parts[0]);
    const month = months[parts[1]];
    const year = parseInt(parts[2]);

    const birth = new Date(year, month, day);
    const now = new Date();
    let age = now.getFullYear() - birth.getFullYear();

    const monthDiff = now.getMonth() - birth.getMonth();
    const dayDiff = now.getDate() - birth.getDate();
    if (monthDiff < 0 || (monthDiff === 0 && dayDiff < 0)) age--;

    return age;
}

function getZodiac(day, monthName) {
    const months = {
        "يناير": 0, "فبراير": 1, "مارس": 2, "أبريل": 3,
        "مايو": 4, "يونيو": 5, "يوليو": 6, "أغسطس": 7,
        "سبتمبر": 8, "أكتوبر": 9, "نوفمبر": 10, "ديسمبر": 11
    };
    const month = months[monthName];

    if (month === undefined) return "غير معروف";

    const zodiacDates = [
        ["الجدي", 19], ["الدلو", 18], ["الحوت", 20], ["الحمل", 19],
        ["الثور", 20], ["الجوزاء", 20], ["السرطان", 22], ["الأسد", 22],
        ["العذراء", 22], ["الميزان", 22], ["العقرب", 21], ["القوس", 21]
    ];

    return (day <= zodiacDates[month][1])
        ? zodiacDates[month][0]
        : zodiacDates[(month + 1) % 12][0];
}

// ================= Handler الامر =================
let handler = async (m, { text, command }) => {
    if (!text) return m.reply(`🎭 اكتب اسم الفنان.\nمثال:\n${command} عصام صاصا`);

    const name = text.trim();
    const birth = db[name];

    if (!birth) return m.reply(`❌ مفيش بيانات عن: *${name}*`);

    let age = getAge(birth);
    let zodiac = "غير معروف";

    if (birth !== "غير مُعلن" && birth.includes(" ")) {
        const [day, month] = birth.split(" ");
        zodiac = getZodiac(parseInt(day), month);
    }

    // ---- تصميم الرد ----
    const replyMessage = `
╔══════════════╗
       🎤 🎬 *معلومات الفنان* 🎬 🎤
╚══════════════╝

✨ *الاسم:* ${name}
📅 *تاريخ الميلاد:* ${birth}
🎚 *العمر:* ${age}
♒ *البرج:* ${zodiac}

💫 استمتع بالمعرفة عن فنانيك المفضلين!
`;

    m.reply(replyMessage);
};

handler.help = ["ميلاد"];
handler.tags = ["info"];
handler.command = /^ميلاد$/i;

export default handler;