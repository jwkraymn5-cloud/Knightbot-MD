/*
Info ff id
By: obito mr
channel: https://whatsapp.com/channel/0029Vb6dsyP3rZZgNJUD2F1A
Api: https://obito-mr-apis.vercel.app
*/

import axios from 'axios';

let handler = async (m, { text, command, usedPrefix}) => {
  if (!text ||!/^\d+$/.test(text)) {
    return m.reply(`⚠️ يرجى إدخال ايدي صالح\nمثال: ${usedPrefix + command} 1010493740`);
}

  try {
    const res = await axios.get(`https://obito-mr-apis.vercel.app/api/info/freefire?id=${text}`);
    const data = res.data;

    if (!data.success ||!data.player) {
      return m.reply('❌ لم يتم العثور على معلومات الحساب.');
}

    const info = data.player.profile_info.basic_info;
    const stats = data.player.profile_info.statistics;

    let reply = `
🎮 *معلومات حساب فري فاير:*
━━━━━━━━━━━━━━
👤 *الاسم:* ${info.Nickname}
🆔 *المعرف:* ${info["Player ID"]}
⭐ *المستوى:* ${info.Level}
📍 *المنطقة:* ${info.Region}
❤️ *الإعجابات:* ${info.Likes}
🎖️ *نقاط الرانك:* ${info["Rank Points"]}
📅 *تاريخ الإنشاء:* ${info["Account Created"]}
🕒 *آخر دخول:* ${info["Last Login"]}
📜 *الوصف:* ${info.Bio}
━━━━━━━━━━━━━━
📊 *إحصائيات اللعب:*
🎮 *المباريات:* ${stats.Matches}
🏆 *الانتصارات:* ${stats.Wins}
🔫 *القتل:* ${stats.Kills}
🎯 *نسبة K/D:* ${stats["K/D Ratio"]}
🔥 *أعلى قتل:* ${stats["Max Kills"]}
💥 *الضرر المتوسط:* ${stats["Average Damage"]}
🚗 *قتل بالمركبة:* ${stats["Vehicle Kills"]}
🎯 *هيدشوت:* ${stats.Headshots}
━━━━━━━━━━━━━━
`;

    m.reply(reply);
} catch (err) {
    console.error(err);
    m.reply('❌ حدث خطأ أثناء جلب المعلومات، حاول لاحقًا.');
}
};

handler.help = ['obito_mr'];
handler.tags = ['obito_mr'];
handler.command = /^(freefire|فريفاير|infoff)$/i;

export default handler;