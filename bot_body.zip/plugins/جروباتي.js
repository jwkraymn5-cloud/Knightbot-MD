let handler = async (m, { conn }) => {

    // جلب جميع الجروبات التي ينتمي إليها البوت
    let groups = Object.entries(conn.chats)
        .filter(([id, chat]) => id.endsWith('@g.us'))

    if (groups.length === 0)
        return m.reply('*⚠️ البوت غير موجود في أي جروب حالياً!*')

    // بناء القائمة الاحترافية
    let txt = `
╭━━━❖•🌌•❖━━━╮
       🌟 *قائمة جروباتي* 🌟
╰━━━❖•💫•❖━━━╯

💠 *إجمالي الجروبات:* ${groups.length}
─────────────────────────
`

    for (let [i, [id, chat]] of groups.entries()) {
        let membersCount = '?'
        try {
            let meta = await conn.groupMetadata(id)
            membersCount = meta.participants.length
        } catch {}
        txt += `
☄️ *${i + 1} — ${chat.subject || 'بدون اسم'}*
👥 الأعضاء: ${membersCount}
─────────────────────────
`
    }

    txt += `
✨ *مصمم:* 𝐁𝐎𝐓 𝐀𝐁𝐎𝐃 🧠
بــﹻ۬ۦٕ٘۬ـــوت عــۥـ℘ـۥــععبودي
`.trim()

    await m.reply(txt)
}

handler.help = ['جروباتي']
handler.tags = ['owner']
handler.command = ['جروباتي','mygroups','groups']
handler.rowner = true

export default handler