/*
🚨 كود عرض قائمة الإنذارات
المصمم: 𝒂𝒃𝒅𝒐 𝑯𝒆𝒓𝒐☠️
*/

const handler = async (m, { conn, isOwner }) => {
  try {
    // الوصول إلى قاعدة بيانات المستخدمين
    const users = global.db.data.users || {};

    // استخراج المستخدمين اللي عندهم إنذارات
    const warnedUsers = Object.entries(users).filter(([jid, data]) => data.warn && data.warn > 0);

    // رسالة في حال لا يوجد إنذارات
    if (warnedUsers.length === 0) {
      return conn.reply(m.chat, "✅ لا يوجد مستخدمين لديهم إنذارات حالياً.", m);
    }

    // إنشاء النص
    const caption = `❪💋❫⇇ *قائمة الإنذارات* ⇇❪💋❫
⧈═━━━━━✦💋✦━━━━━═⧈
${warnedUsers
  .map(
    ([jid, data], i) =>
      `❪💋❫⇇ *${i + 1}.* المستخدم ⇇❪@${jid.split("@")[0]}❫
*┊ إنذاراته:* ❪${data.warn}/3❫`
  )
  .join("\n⧈═━━━━━✦💋✦━━━━━═⧈\n")}
⧈═━━━━━✦💋✦━━━━━═⧈

✨ المصمم: 𝒂𝒃𝒅𝒐 𝑯𝒆𝒓𝒐☠️`;

    // إرسال تفاعل (إيموجي)
    await conn.sendMessage(m.chat, { react: { text: "🚨", key: m.key } });

    // إرسال القائمة مع منشنات
    await conn.sendMessage(
      m.chat,
      {
        text: caption,
        mentions: warnedUsers.map(([jid]) => jid),
      },
      { quoted: m }
    );
  } catch (e) {
    console.error(e);
    conn.reply(m.chat, "❌ حدث خطأ أثناء عرض قائمة الإنذارات.", m);
  }
};

// إعدادات الأمر
handler.command = /^(listwarn|الانذارات|التحذيرات)$/i;
handler.group = true;
handler.admin = true;

export default handler;