// ⚡ كود لوفي الفخم - كشف الرقم و طرده من جميع الجروبات ⚡
// ❥ 𝑨𝒅𝒉𝒂𝒎 ❥

let handler = async (m, { conn, text, command }) => {
  if (!text && !m.mentionedJid[0] && !m.quoted)
    return m.reply(`⚠️︙مـنـشـن الـشـخـص أو أرسـل رقـمـه بـعـد الأمـر يـا صـديـق ☠️`);

  // استخراج الرقم أو المستخدم المستهدف
  let user =
    m.mentionedJid[0] ||
    (m.quoted ? m.quoted.sender : null) ||
    (text ? text.replace(/[^0-9]/g, '') + '@s.whatsapp.net' : null);

  if (!user) return m.reply('❌︙لـم يـتـم الـعـثـور عـلـى هـذا الـرقـم!');

  // رسالة تفاعلية أولية
  let actionMsg =
    command === 'خرجوه'
      ? `*╭━─━⊱❥ لوفي ☠️ ❥⊰━─━╮*\n*⛓️ جاري طرد الرقم من كل الجروبات...*\n*العملية بدأت يا صديقي!* ⚡`
      : `*╭━─━⊱❥ لوفي ☠️ ❥⊰━─━╮*\n*🔍 جاري البحث عن الرقم في جميع الجروبات...*\n*انتظر قليلًا أيها القرصان!* ☠️`;
  await m.reply(actionMsg);

  // جمع الجروبات
  let allGroups = Object.entries(conn.chats)
    .filter(([jid, chat]) => jid.endsWith('@g.us') && chat?.metadata)
    .map(([jid, chat]) => chat.metadata);

  let foundGroups = [];
  for (let group of allGroups) {
    if (group.participants.some((p) => p.id === user)) foundGroups.push(group);
  }

  // أمر كشف الرقم
  if (command === 'كشف-الرقم') {
    if (foundGroups.length === 0) {
      return m.reply(
        `*╔══❀•°:🌹:°•❀══╗*\n` +
        `*✦ لـم أجـد هـذا الـرقـم فـي أي جـروب نـشـاركـه مـعًا!* ⚓\n` +
        `*يـبـدو أنـه غـارق فـي بـحـارٍ أخـرى!* 🌊\n` +
        `*╚══❀•°:☠️:°•❀══╝*\n\n` +
        `*⌜❥ لوفي ☠️ ❥⌟*\n*╰━═━⊱❥ 𝑨𝒅𝒉𝒂𝒎 ❥⊰━═━╯*`
      );
    } else {
      let msg = `*╭━─━⊱❥ لوفي ☠️ ❥⊰━─━╮*\n` +
                `*📜 الـرقـم موجـود مـعـنـا فـي ${foundGroups.length} جـروب:*\n\n`;
      for (let g of foundGroups) msg += `╰◉ ${g.subject}\n`;
      msg += `\n*╰━═━⊱❥ 𝑨𝒅𝒉𝒂𝒎 ❥⊰━═━╯*`;
      return m.reply(msg);
    }
  }

  // أمر خرجوه
  if (command === 'خرجوه') {
    let removed = 0;
    for (let group of foundGroups) {
      try {
        // تحقق أن البوت أدمن
        let bot = group.participants.find((p) => p.id === conn.user.jid);
        if (!bot?.admin) continue;

        await conn.groupParticipantsUpdate(group.id, [user], 'remove');
        removed++;
        await new Promise((res) => setTimeout(res, 700)); // تأخير بسيط بين الطرد
      } catch (e) {
        console.log(`❌ خطأ في ${group.subject}:`, e);
      }
    }

    if (removed === 0) {
      return m.reply(
        `*╔══❀•°:💢:°•❀══╗*\n` +
        `*✦ لـم أستـطـع إخـراجـه، يـبـدو أنـي لست أدمن فـي أي جـروب مـشـتـرك!* ⚔️\n` +
        `*╚══❀•°:☠️:°•❀══╝*\n\n` +
        `*⌜❥ لوفي ☠️ ❥⌟*\n*╰━═━⊱❥ 𝑨𝒅𝒉𝒂𝒎 ❥⊰━═━╯*`
      );
    } else {
      return m.reply(
        `*❍━━━══━━❪☠️❫━━══━━━❍*\n` +
        `*『⌜❥ لوفي ☠️ ❥⌟』*\n\n` +
        `*⚡ تـم إخـراج هـذا الـرقـم مـن ${removed} جـروب بـأمـر القبطان ❥ 𝑨𝒅𝒉𝒂𝒎 ❥ ⚓*\n` +
        `*╰━═━⊱❥ الـعـدل الـحـقّ ❥⊰━═━╯*`
      );
    }
  }
};

handler.help = ['بحث-الرقم', 'خرجوه'];
handler.tags = ['group', 'owner'];
handler.command = ['بحث-الرقم', 'خرجوه'];
handler.owner = true;

export default handler;