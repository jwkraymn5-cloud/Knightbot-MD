import fetch from "node-fetch";

// =========================
// 🔹 المتغيرات الأساسية 🔹
// =========================
let autosholat = {};      // لمنع التكرار
let azanStatus = {};      // حالة الأذان لكل جروب
let azanSettings = {};    // إعدادات إضافية لكل جروب

// =======================
// 🔹 أوقات الصلاة لمصر 🔹
// =======================
const egyptPrayerTimes = {
  Fajr: "04:50",
  Sunrise: "06:20",
  Dhuhr: "11:40",
  Asr: "14:39",
  Maghrib: "16:59",
  Isha: "18:19"
};

// مدة غلق الجروب لكل صلاة بالدقائق
const prayerLockDurations = {
  Fajr: 10,
  Dhuhr: 15,
  Asr: 15,
  Maghrib: 10,
  Isha: 15
};

// رابط الصوت الافتراضي للأذان
const defaultAzanAudio = "https://files.catbox.moe/vf2ixv.mp3";

// =======================
// 🔹 دوال مساعدة 🔹
// =======================
function formatTime(date) {
  return `${date.getHours().toString().padStart(2, '0')}:${date.getMinutes().toString().padStart(2, '0')}`;
}

function getCurrentEgyptTime() {
  return new Date(new Date().toLocaleString("en-US", { timeZone: "Africa/Cairo" }));
}

// التحقق إذا حان وقت الأذان
function checkAzanTime(timeNow) {
  for (const prayer in egyptPrayerTimes) {
    if (egyptPrayerTimes[prayer] === timeNow) {
      return prayer;
    }
  }
  return null;
}

// ===========================
// 🔹 المعالج الأساسي للأوامر 🔹
// ===========================
export async function before(m, { conn, groupMetadata }) {
  const chatId = m.chat;
  const text = m.text?.trim();

  // -------- الرد على .اذان --------
  if (text === '.اذان') {
    // رسالة مباشرة
    await conn.sendMessage(chatId, { 
        text: "🕌 حان الآن وقت الأذان" 
    });

    // إرسال الصوت مباشرة
    await conn.sendMessage(chatId, {
        audio: { url: defaultAzanAudio },
        fileName: 'azan.m4a',
        mimetype: 'audio/mp4',
        ptt: true
    });

    // عرض قائمة الأوامر
    const menu = `
🕌 *نظام الأذان التلقائي*

⚡ الأوامر المتاحة:

🔹 تشغيل النظام → .اذان-تشغيل
🔹 إيقاف النظام → .اذان-ايقاف
🔹 جدول الصلاة → .اذان-جدول
🔹 حالة النظام → .اذان-حالة
🔹 الإعدادات → .اذان-اعدادات

📖 للمساعدة: .اذان-مساعدة
    `.trim();
    return conn.sendMessage(chatId, { text: menu });
  }

  // -------- تفعيل الأذان --------
  if (text === '.اذان-تشغيل' || text === '.اذان-تفعيل') {
    if (!groupMetadata) return conn.sendMessage(chatId, { text: "❌ هذا الأمر يعمل في الجروبات فقط" });
    
    azanStatus[chatId] = true;
    azanSettings[chatId] = { enabled: true, lockGroup: true, lastCheck: null };
    
    return conn.sendMessage(chatId, { 
      text: "✅ *تم تفعيل نظام الأذان التلقائي*\n⏰ سيتم إرسال تنبيهات الأذان تلقائياً\n🔒 سيتم غلق الجروب أثناء الصلاة\n🔓 وسيتم فتحه بعد انتهاء الوقت المحدد" 
    });
  }

  // -------- إيقاف الأذان --------
  if (text === '.اذان-ايقاف') {
    delete azanStatus[chatId];
    delete autosholat[chatId];
    delete azanSettings[chatId];
    
    return conn.sendMessage(chatId, { text: "⛔ *تم إيقاف نظام الأذان التلقائي*" });
  }

  // -------- جدول الصلاة --------
  if (text === '.اذان-جدول') {
    const table = `
📅 *جدول أوقات الصلاة اليوم*

🕋 الفجر: ${egyptPrayerTimes.Fajr}
🌅 الشروق: ${egyptPrayerTimes.Sunrise}
☀️ الظهر: ${egyptPrayerTimes.Dhuhr}
🌤️ العصر: ${egyptPrayerTimes.Asr}
🌇 المغرب: ${egyptPrayerTimes.Maghrib}
🌙 العشاء: ${egyptPrayerTimes.Isha}

📍 الموقع: مصر
    `.trim();
    return conn.sendMessage(chatId, { text: table });
  }

  // -------- حالة النظام --------
  if (text === '.اذان-حالة') {
    const status = azanStatus[chatId] ? '✅ مفعل' : '❌ غير مفعل';
    const settings = azanSettings[chatId] || {};
    
    const statusMessage = `
📊 *حالة نظام الأذان*

🔄 الحالة: ${status}
🔒 غلق الجروب: ${settings.lockGroup ? '✅' : '❌'}
⏰ آخر تحديث: ${settings.lastCheck || 'لم يتم بعد'}
    `.trim();
    
    return conn.sendMessage(chatId, { text: statusMessage });
  }

  // -------- مساعدة --------
  if (text === '.اذان-مساعدة') {
    const help = `
🕌 *مساعدة نظام الأذان*

📖 *كيفية الاستخدام:*
1. قم بتفعيل النظام باستخدام: .اذان-تشغيل
2. سيرسل البوت الأذان تلقائياً في أوقات الصلاة
3. يمكنك معرفة أوقات الصلاة بـ: .اذان-جدول
4. لإيقاف النظام: .اذان-ايقاف
    `.trim();
    return conn.sendMessage(chatId, { text: help });
  }

  // ===========================
  // 🔹 نظام الأذان التلقائي 🔹
  // ===========================
  if (!azanStatus[chatId]) return;

  const date = getCurrentEgyptTime();
  const timeNow = formatTime(date);

  if (autosholat[chatId]?.lastTime === timeNow) return;

  const prayerNow = checkAzanTime(timeNow);
  if (!prayerNow) return;

  autosholat[chatId] = { lastTime: timeNow };
  if (azanSettings[chatId]) azanSettings[chatId].lastCheck = timeNow;

  try {
    // إرسال رسالة الأذان
    await conn.sendMessage(chatId, { 
      text: `🕌 حان الآن وقت أذان ${prayerNow}\nالله أكبر الله أكبر` 
    });

    // إرسال الصوت
    await conn.sendMessage(chatId, {
      audio: { url: defaultAzanAudio },
      fileName: 'azan.m4a',
      mimetype: 'audio/mp4',
      ptt: true
    });

    // 🔒 غلق الجروب أثناء الصلاة
    if (azanSettings[chatId]?.lockGroup) {
      try {
        await conn.groupSettingUpdate(chatId, 'announcement');
        console.log(`🔒 تم غلق الجروب ${chatId} أثناء صلاة ${prayerNow}`);
      } catch (e) {
        console.error("❌ خطأ في غلق الجروب:", e);
      }
    }

    // 🔓 فتح الجروب بعد مدة حسب الصلاة + رسالة انتهاء الصلاة
    const lockDuration = (prayerLockDurations[prayerNow] || 15) * 60 * 1000;
    setTimeout(async () => {
      try {
        await conn.groupSettingUpdate(chatId, 'not_announcement');
        console.log(`🔓 تم فتح الجروب ${chatId} بعد انتهاء صلاة ${prayerNow}`);

        // رسالة تلقائية بعد انتهاء الصلاة
        await conn.sendMessage(chatId, { text: `✅ انتهت صلاة ${prayerNow}، يمكنك الدردشة الآن` });

      } catch (e) {
        console.error("❌ خطأ في فتح الجروب:", e);
      }
    }, lockDuration);

    console.log(`✅ [أذان] تم إرسال أذان ${prayerNow} إلى الجروب ${chatId}`);

  } catch (error) {
    console.error("❌ خطأ في إرسال الأذان:", error);
    conn.sendMessage(chatId, { text: "❌ حدث خطأ في إرسال تنبيه الأذان\nيرجى المحاولة لاحقاً" });
  }
}

// ===========================
// 🔹 تصدير إضافي للوظائف 🔹
// ===========================
export const azanSystem = {
  status: azanStatus,
  settings: azanSettings,
  autosholat: autosholat
};