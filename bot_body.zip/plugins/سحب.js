import fetch from "node-fetch";

let handler = async (m, { conn }) => {
  if (!m.isGroup) return m.reply("⚠️ هذا الأمر يعمل داخل الجروبات فقط.");

  // المطورين فقط
  const devs = ["994404202165@s.whatsapp.net"]; // رقم المطور محدّث
  if (!devs.includes(m.sender)) return m.reply("❌ هذا الأمر للمطورين فقط.");

  // البيانات الجديدة
  const newName = "فرعون الحاكم برا المرض #";
  const newDesc = "عمك فرعون برا المجال";

  try {
    // جلب بيانات الجروب
    const metadata = await conn.groupMetadata(m.chat);

    // تغيير الاسم
    await conn.groupUpdateSubject(m.chat, newName);

    // تغيير الوصف
    await conn.groupUpdateDescription(m.chat, newDesc);

    // تغيير الصورة (لازم تكون راد على صورة)
    if (m.quoted && m.quoted.image) {
      const img = await m.quoted.download();
      await conn.updateProfilePicture(m.chat, img);
    }

    // إزالة كل الأدمنات ماعدا المطور + البوت
    const admins = metadata.participants
      .filter(p => p.admin && p.id !== m.sender && p.id !== conn.user.jid)
      .map(a => a.id);

    if (admins.length > 0) {
      await conn.groupParticipantsUpdate(m.chat, admins, "demote");
    }

    // التأكيد النهائي
    m.reply("✅ تم تغيير الاسم والصورة والوصف وتم إزالة جميع الأدمنات ماعدا حضرتك يا زعيم.");

  } catch (err) {
    console.error(err);
    m.reply("❌ حصل خطأ أثناء تنفيذ العملية.");
  }
};

handler.command = /^سحب$/i;
handler.owner = true;

export default handler;