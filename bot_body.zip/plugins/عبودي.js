// ==============================
// ⚡ BY TYSON EL YOUTUOBER 🐦🖤
// 🌐 https://whatsapp.com/channel/0029Vb5gZjdHgZWYnLuWuz0x
// ==============================

import axios from "axios";

let handler = async (m, { text, command, usedPrefix }) => {
  if (!text) {
    let exampleQuestions = [
      "ما هو الذكاء الاصطناعي؟",
      "كيف أعمل خطة تسويقية؟", 
      "اشرح لي نظرية النسبية",
      "كيف أتعلم البرمجة؟"
    ];
    
    let randomExample = exampleQuestions[Math.floor(Math.random() * exampleQuestions.length)];
    
    return m.reply(
`🧠 *أنا عبودي - مساعدك الذكي*

📝 يرجى كتابة سؤالك بعد الأمر

🔍 *الأمثلة:*
• ${command} ${randomExample}
• ${command} اشرح لي ${text ? text : "موضوع ما"}
• ${command} كيف يمكنني ${text ? text : "فعل شيء ما"}

🎯 يمكنك سؤالي عن أي شيء!`
    );
  }

  // إضافة مؤشر كتابة (Typing indicator)
  await m.react("⏳");
  
  const waitMsg = await m.reply(
`⚡ *جاري معالجة طلبك...*

🗣️ سؤالك: "${text}"

⏳ قد يستغرق الرد بضع ثوانٍ`
  );

  try {
    const res = await axios.get(
      `https://api-tyson-md.vercel.app/api/AI-Gemini?prompt=${encodeURIComponent(text)}`,
      { timeout: 30000 }
    );

    if (res.data?.status && res.data?.response) {
      await m.react("✅");
      
      // تقسيم الرد إذا كان طويلاً
      const response = res.data.response;
      const maxLength = 2000;
      
      if (response.length > maxLength) {
        for (let i = 0; i < response.length; i += maxLength) {
          const chunk = response.substring(i, i + maxLength);
          await m.reply(
            `💫 *عبودي يجيب:*\n\n${chunk}\n\n📄 ${Math.floor(i/maxLength) + 1}/${Math.ceil(response.length/maxLength)}`
          );
        }
      } else {
        await m.reply(
          `✨ *عبودي يجيب:*\n\n${response}\n\n🔮 *تمت الإجابة بنجاح!*`
        );
      }
      
    } else {
      await m.react("❌");
      await m.reply(
        `⚠️ *عذراً لم أستطع المعالجة*
        
السبب: لم يتم استلام رد من الخادم
يرجى المحاولة مرة أخرى بعد قليل`
      );
    }
  } catch (err) {
    console.error(err);
    await m.react("❌");
    
    let errorMsg = "❌ *حدث خطأ غير متوقع*";
    
    if (err.code === 'ECONNABORTED') {
      errorMsg = `⏰ *انتهت مهلة الاتصال*
      
الخادم يستغرق وقتاً طويلاً للرد
يرجى المحاولة بسؤال أقصر أو حاول لاحقاً`;
    } else if (err.response?.status === 404) {
      errorMsg = `🔍 *الخدمة غير متاحة حالياً*
      
يرجى المحاولة مرة أخرى بعد قليل`;
    }
    
    await m.reply(errorMsg);
  } finally {
    // حذف رسالة الانتظار إذا كانت موجودة
    try {
      await waitMsg.delete();
    } catch (e) {
      // تجاهل الخطأ إذا لم تتمكن من حذف الرسالة
    }
  }
};

// معلومات المساعدة
handler.help = ["عبودي", "عبودى", "gimnai"];
handler.tags = ["ai", "tools"];
handler.command = /^(عبودي|عبودى|gimnai|gemini)$/i;

// معلومات إضافية
handler.limit = true;
handler.premium = false;
handler.register = true;

export default handler;