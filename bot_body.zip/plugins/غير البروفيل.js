/*
BY : *كونل*

*⎔ ⋅ ───━ •﹝🧞﹞• ━─── ⋅ ⎔*
*/

import uploadImage from '../lib/uploadImage.js'

let handler = async (m, { conn, isAdmin, isBotAdmin }) => {
  if (!m.isGroup) return m.reply('*⛔ هذا الأمر يعمل فقط داخل الجروبات.*')
  if (!isBotAdmin) return m.reply('*⚠️ لازم البوت يكون أدمن علشان يقدر يغير صورة الجروب.*')
  if (!isAdmin) return m.reply('*🚫 فقط المشرفين يمكنهم تغيير صورة الجروب.*')

  let q = m.quoted ? m.quoted : m
  let mime = (q.msg || q).mimetype || ''
  if (!mime.startsWith('image/')) 
    return m.reply('*📸 من فضلك، قم بالرد على صورة بالأمر 「غير-البروفيل」 لتغيير صورة الجروب.*')

  await m.react('⏳')
  try {
    // تحميل الصورة
    let img = await q.download()

    // تغيير بروفايل الجروب
    await conn.updateProfilePicture(m.chat, img)

    await m.react('✅')

    // رسالة نجاح جميلة بعد التغيير
    let text = `
*⎔ ⋅ ───━ •﹝🧞﹞• ━─── ⋅ ⎔*
✨ تم تجديد شكل الجروب بنجاح!  
بواسطة : *${m.pushName}* 💫  
📸 البوت قام بتغيير صورة الجروب الآن ⚜️  
*⎔ ⋅ ───━ •﹝🌙 *كونل* 🌙﹞• ━─── ⋅ ⎔*
`

    await conn.sendMessage(m.chat, { text }, { quoted: m })
  } catch (err) {
    console.error(err)
    await m.react('❌')
    await conn.reply(m.chat, '❌ حدث خطأ أثناء محاولة تغيير صورة الجروب.\nتأكد أن البوت أدمن وحاول مرة أخرى.', m)
  }
}

handler.help = ['غير-البروفيل']
handler.tags = ['group']
handler.command = ['غير-البروفيل']

export default handler