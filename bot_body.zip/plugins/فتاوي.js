/*
جلب الفتاوي سؤال وجواب معا تفاصيل
by obito mr
https://whatsapp.com/channel/0029Vb6dsyP3rZZgNJUD2F1A
https://obito-mr-apis.vercel.app
*/

import fetch from 'node-fetch';
import { generateWAMessageFromContent } from '@whiskeysockets/baileys';


const userPages = new Map();

const handler = async (m, { conn, usedPrefix, command, text }) => {
    try {
        await conn.sendMessage(m.chat, { react: { text: '📖', key: m.key } });


        const currentPage = userPages.get(m.sender) || 1;
        

        const fatawaData = await fetchFatawaPage(currentPage);
        
        if (!fatawaData || !fatawaData.fatawa || fatawaData.fatawa.length === 0) {
            return conn.reply(m.chat, 
                '❌ *لم يتم العثور على فتاوى في هذه الصفحة!*\n' +
                'قد تكون وصلت إلى نهاية الفتاوى.',
                m
            );
        }


        const interactiveMessage = createFatawaListMessage(fatawaData, currentPage, usedPrefix);
        
        let msg = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: { message: { interactiveMessage } }
        }, { userJid: conn.user.jid, quoted: m });

        await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
        await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

    } catch (error) {
        console.error('Error in fatawa handler:', error);
        conn.reply(m.chat, 
            `❌ *حدث خطأ أثناء جلب الفتاوى!*\n⚠️ *التفاصيل:* ${error.message}`,
            m
        );
    }
};


async function fetchFatawaPage(page = 1) {
    try {
        const apiUrl = `https://obito-mr-apis.vercel.app/api/islam/fatawa?limit=${page}`;
        
        const response = await fetch(apiUrl);
        
        if (!response.ok) {
            throw new Error(`فشل في جلب الفتاوى: ${response.status}`);
        }

        const data = await response.json();
        
        if (!data.success) {
            throw new Error(data.message || 'فشل في جلب البيانات');
        }


        const allFatawa = data.data.fatawa || [];
        const startIndex = Math.max(0, allFatawa.length - 12); 
        const pageFatawa = allFatawa.slice(startIndex);

        return {
            fatawa: pageFatawa,
            currentPage: page,
            totalPages: data.data.totalPages || page,
            totalFatawa: data.data.totalFatawa || 0
        };

    } catch (error) {
        console.error('Error fetching fatawa page:', error);
        throw error;
    }
}


function createFatawaListMessage(fatawaData, currentPage, usedPrefix) {
    const { fatawa, totalFatawa } = fatawaData;
    

    const fatawaSections = fatawa.map((fatwa, index) => ({
        title: `📜 ${fatwa.title.substring(0, 20)}${fatwa.title.length > 20 ? '...' : ''}`,
        rows: [
            {
                title: `👤 ${fatwa.scholar}`,
                description: `📅 ${fatwa.time} | 👁️ ${fatwa.views}`,
                id: `${usedPrefix}فتوى-معلومات ${fatwa.url}`
            }
        ]
    }));


    const quickReplyButtons = [
        {
            name: 'quick_reply',
            buttonParamsJson: JSON.stringify({
                display_text: "📄 اضافة الفتاوي التالية",
                id: `${usedPrefix}فتاوى ${currentPage + 1}`
            })
        }
    ];

    return {
        body: { 
            text: `*📖 فتاوى طريق الإسلام - الصفحة ${currentPage}*\n\n` +
                  `*تم العثور على ${totalFatawa} فتوى*\n\n` +
                  `*اختر فتوى لعرض معلوماتها:*` 
        },
        footer: { text: "🕌 الفتاوي الاسلاميه - تم بواسطة obito mr" },
        nativeFlowMessage: {
            buttons: [
                {
                    name: 'single_select',
                    buttonParamsJson: JSON.stringify({
                        title: '❲ 📜 قائمة الفتاوى ❳',
                        sections: fatawaSections
                    })
                },
                ...quickReplyButtons
            ],
            messageParamsJson: ''
        }
    };
}


const showFatwaInfo = async (m, { conn, args, usedPrefix }) => {
    if (!args[0]) {
        return conn.reply(m.chat, 
            '❌ *يرجى تقديم رابط الفتوى!*\n' +
            'استخدم الأمر: ' + usedPrefix + 'فتاوى',
            m
        );
    }

    try {
        await conn.sendMessage(m.chat, { react: { text: '🔍', key: m.key } });

        const fatwaUrl = args[0];
        
 
        const fatwaData = await fetchFullFatwa(fatwaUrl);
        
        if (!fatwaData) {
            throw new Error('فشل في جلب معلومات الفتوى');
        }


        const interactiveMessage = createFatwaInfoMessage(fatwaData, fatwaUrl, usedPrefix);
        
        let msg = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: { message: { interactiveMessage } }
        }, { userJid: conn.user.jid, quoted: m });

        await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
        await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

    } catch (error) {
        console.error('Error in fatwa info:', error);
        conn.reply(m.chat, 
            `❌ *حدث خطأ أثناء عرض معلومات الفتوى!*\n⚠️ *التفاصيل:* ${error.message}`,
            m
        );
    }
};


function createFatwaInfoMessage(fatwaData, fatwaUrl, usedPrefix) {
    const {
        title,
        scholar,
        fullQuestion,
        fullAnswer,
        time,
        views,
        upVotes,
        downVotes,
        tags = [],
        source
    } = fatwaData;


    const shortQuestion = fullQuestion.length > 200 ? 
        fullQuestion.substring(0, 200) + '...' : fullQuestion;
    
    const shortAnswer = fullAnswer.length > 150 ? 
        fullAnswer.substring(0, 150) + '...' : fullAnswer;

    const infoText = `*📋 معلومات الفتوى*\n\n` +
                    `*📜 العنوان الكامل:*\n${title}\n\n` +
                    `*👤 المفتي:* ${scholar}\n` +
                    `*📅 التاريخ:* ${time}\n` +
                    `*📊 الإحصائيات:* 👁️ ${views} | 👍 ${upVotes} | 👎 ${downVotes}\n\n` +
                    `*❓ السؤال:*\n${shortQuestion}\n\n` +
                    `*💡 الإجابة:*\n${shortAnswer}\n\n` +
                    `${tags.length > 0 ? `*🏷️ التصنيفات:* ${tags.join('، ')}\n\n` : ''}` +
                    `> BY OBITO MR`;

    return {
        body: { text: infoText },
        footer: { text: "انقر على زر 'جلب الفتوى' لعرض المحتوى الكامل" },
        nativeFlowMessage: {
            buttons: [
                {
                    name: 'quick_reply',
                    buttonParamsJson: JSON.stringify({
                        display_text: "📥 جلب الفتوى",
                        id: `${usedPrefix}جلب-فتوى ${fatwaUrl}`
                    })
                }
            ],
            messageParamsJson: ''
        }
    };
}


const getFullFatwa = async (m, { conn, args, usedPrefix }) => {
    if (!args[0]) {
        return conn.reply(m.chat, 
            '❌ *يرجى تقديم رابط الفتوى!*',
            m
        );
    }

    try {
        await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

        const fatwaUrl = args[0];
        const fatwaData = await fetchFullFatwa(fatwaUrl);
        
        if (!fatwaData) {
            throw new Error('فشل في جلب الفتوى الكاملة');
        }

      
        const formattedMessage = formatFatwaMessage(fatwaData);
        
 
        if (Array.isArray(formattedMessage)) {
            for (const part of formattedMessage) {
                await conn.reply(m.chat, part, m);
                await new Promise(resolve => setTimeout(resolve, 500)); 
            }
        } else {
            await conn.reply(m.chat, formattedMessage, m);
        }
        
        await conn.sendMessage(m.chat, { react: { text: '📖', key: m.key } });

    } catch (error) {
        console.error('Error fetching full fatwa:', error);
        conn.reply(m.chat, 
            `❌ *حدث خطأ أثناء جلب الفتوى الكاملة!*\n⚠️ *التفاصيل:* ${error.message}`,
            m
        );
    }
};


async function fetchFullFatwa(fatwaUrl) {
    try {
        const apiUrl = `https://obito-mr-apis.vercel.app/api/islam/fatawa_get?url=${encodeURIComponent(fatwaUrl)}`;
        
        const response = await fetch(apiUrl);
        
        if (!response.ok) {
            throw new Error(`فشل في جلب الفتوى: ${response.status}`);
        }

        const data = await response.json();
        
        if (!data.success) {
            throw new Error(data.message || 'فشل في جلب الفتوى');
        }

        return data.data;

    } catch (error) {
        console.error('Error fetching full fatwa:', error);
        throw error;
    }
}


function formatFatwaMessage(fatwaData) {
    const {
        title,
        scholar,
        fullQuestion,
        fullAnswer,
        time,
        views,
        upVotes,
        downVotes,
        tags = [],
        source,
        description
    } = fatwaData;

    let message = `*📖 الفتوى كاملة*\n\n`;
    message += `*🏷️ العنوان:* ${title}\n`;
    message += `*👤 المفتي:* ${scholar}\n`;
    message += `*📅 التاريخ:* ${time}\n`;
    message += `*📊 الإحصائيات:* 👁️ ${views} | 👍 ${upVotes} | 👎 ${downVotes}\n`;
    
    if (source) {
        message += `*📚 المصدر:* ${source}\n`;
    }
    
    if (tags.length > 0) {
        message += `*🏷️ التصنيفات:* ${tags.join('، ')}\n`;
    }
    
    message += `\n*❓ السؤال:*\n${fullQuestion}\n\n`;
    message += `*💡 الإجابة:*\n${fullAnswer}\n\n`;
    
    if (description) {
        message += `*📝 ملخص:* ${description}\n\n`;
    }
    
    message += `*🕌 طريق الإسلام - الفتاوى الشرعية*`;


    if (message.length > 4000) {

        const questionPart = `*📖 الفتوى كاملة - الجزء ١/٢*\n\n` +
                           `*🏷️ العنوان:* ${title}\n` +
                           `*👤 المفتي:* ${scholar}\n` +
                           `*📅 التاريخ:* ${time}\n\n` +
                           `*❓ السؤال:*\n${fullQuestion.substring(0, 1500)}${fullQuestion.length > 1500 ? '...' : ''}`;
        

        const answerPart = `*📖 الفتوى كاملة - الجزء ٢/٢*\n\n` +
                          `*💡 الإجابة:*\n${fullAnswer.substring(0, 1500)}${fullAnswer.length > 1500 ? '...' : ''}\n\n` +
                          `*📊 الإحصائيات:* 👁️ ${views} | 👍 ${upVotes} | 👎 ${downVotes}\n` +
                          `*🕌 الفتاوي الاسلاميه - تم بواسطة obito mr*`;
        
        return [questionPart, answerPart];
    }

    return message;
}


const obitoMrHandler = async (m, context) => {
    const { usedPrefix, command, text, args } = context;
    
    if (command === 'فتاوى') {

        if (args[0] && !isNaN(args[0])) {
            const pageNum = parseInt(args[0]);
            userPages.set(m.sender, pageNum);
        } else {

            userPages.set(m.sender, 1);
        }
        return handler(m, context);
    }
    
    if (command === 'فتوى-معلومات') {
        return showFatwaInfo(m, context);
    }
    
    if (command === 'جلب-فتوى') {
        return getFullFatwa(m, context);
    }
};


obitoMrHandler.command = /^(فتاوى|فتوى-معلومات|جلب-فتوى)$/i;

export default obitoMrHandler;