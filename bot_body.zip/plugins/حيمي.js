import fetch from "node-fetch";

let handler = async (m, { conn, args }) => {
  const text = args.join(" ");

  // ============ زر تلقائي لو مفيش نص ============
  if (!text) {
    return conn.sendMessage(
      m.chat,
      {
        text: "✨ *اختار نوع الصورة اللي عايزها*",
        footer: "Gemi AI",
        templateButtons: [
          {
            index: 1,
            quickReplyButton: {
              displayText: "🎀 صورة بنت",
              id: ".gemi صورة بنت جميلة"
            },
          },
          {
            index: 2,
            quickReplyButton: {
              displayText: "🌅 غروب الشمس",
              id: ".gemi منظر غروب الشمس"
            },
          },
        ],
      },
      { quoted: m }
    );
  }

  // ============ طلب الصورة بالنص نفسه ============
  const apiURL =
    "https://tyson-dev.vercel.app/api/gemi?text=" + encodeURIComponent(text);

  try {
    let wait = await conn.sendMessage(
      m.chat,
      { text: "⏳ *جاري إنشاء الصورة... استنى ثانية*" },
      { quoted: m }
    );

    // نحاول نجيب الصورة
    let res = await fetch(apiURL);
    let raw = await res.text();

    let data;
    try {
      data = JSON.parse(raw);
    } catch {
      data = { image: apiURL };
    }

    let imageUrl = data.image || apiURL;

    // نحذف رسالة الانتظار
    await conn.sendMessage(m.chat, { delete: wait.key });

    // نرسل الصورة
    return conn.sendMessage(
      m.chat,
      {
        image: { url: imageUrl },
        caption: `✔️ *تم تنفيذ طلبك:*  
"${text}"`,
      },
      { quoted: m }
    );
  } catch (e) {
    console.log("ERROR:", e);
    return conn.reply(
      m.chat,
      "❌ حصل خطأ، السيرفر ممكن يكون واقع. جرّب بعد دقيقة.",
      m
    );
  }
};

handler.command = /^gemi|جيمي|صورة|تصميم|انشاء$/i;

export default handler;