const handler = async (m, { conn }) => {
    const imageUrl = "https://files.catbox.moe/mk5pxb.jpg";
    const link1 = "https://wa.me/201119779522";

    // الرسالة الأولى: externalAdReply مع صورة كبيرة
    const adMessage = {
        text: "> بــ؏ــد غــيـآب طــوُيـل خـرجـت لَڪــم مِـن آلـجـحـيـم… إسـمـي عبودي بــوُت، مـطـوري عبودي ‌ آلإذآعـه اسـتـخـدم امـر (.اوامـر) لطلب الـقـائـمـة",
        contextInfo: {
            externalAdReply: {
                title: "｢🐥┊𝐁𝐎𝐓 |𝐀𝐁𝐎𝐃 ┊⛄｣",
                body: "｢🧸┆𝐵𝑂𝐷𝑌|𝐵𝑂𝑇┆❄️｣",
                thumbnailUrl: imageUrl,
                mediaType: 1,
                renderLargerThumbnail: true,
                sourceUrl: link1
            }
        }
    };

    await conn.sendMessage(m.chat, adMessage, { quoted: m });

    // الرسالة الثانية: أزرار
    const buttons = [
        { buttonId: ".اوامر", buttonText: { displayText: "⌈🚀╎اوامر╎🚀⌋" }, type: 1 },
        { buttonId: "المطور", buttonText: { displayText: "⌈👑╎المطور╎👑⌋" }, type: 1 }
    ];

    const buttonMessage = {
        text: "اختر من الأزرار التالية:",
        buttons: buttons,
        footer: "> BOT&BODY",
        headerType: 1
    };

    await conn.sendMessage(m.chat, buttonMessage, { quoted: m });
};

handler.command = /^بوت$/i;

export default handler;