const handler = async (m, { conn }) => {

    const imageUrl = "https://files.catbox.moe/4v91ll.jpg";

    const messageText = `

*╔══✦〘💻〙✦══╗*
  『 مـرحـبــاً بـك يـا ⌊ ${m.pushName} ⌉ 』
        فــي قـســم الـبـرمجــة
      داخـل بـوت *『 𝐁𝐎𝐓 𝐀𝐁𝐎𝐃 🧠 بــﹻ۬ۦٕ٘۬ـــوت عــۥـ℘ـۥــمطور 』*
*╚══✦〘💻〙✦══╝*

*⌝ قــســم الـبــرمجــة ┋💻⌞ ⇊*
*⎔ ⋅ ───━ •﹝🐦‍🔥﹞• ━─── ⋅ ⎔*

*💻┊⇇ 『 إحــســب-الــحــروف 』*  
*📎┊⇇ 『 إخــتـصــار-إنــشــاء 』*  
*📎┊⇇ 『 إخــتـصــار 』*  
*🌐┊⇇ 『 أيــ-بــي 』*  
*📶┊⇇ 『 بــنــج 』*  
*📄┊⇇ 『 بــي-دي-اف 』*  
*✨┊⇇ 『 تــشــويــش 』*  
*🧪┊⇇ 『 دي-أن-أس 』*  
*🔍┊⇇ 『 فــحــص-الـمــوقــع 』*  
*🧾┊⇇ 『 هــيــدر 』*

*⎔ ⋅ ───━ •﹝🐦‍🔥﹞• ━─── ⋅ ⎔*

> ⚡ بــوتــك مـع *『 𝐁𝐎𝐓 𝐀𝐁𝐎𝐃 🧠 بــﹻ۬ۦٕ٘۬ـــوت عــۥـ℘ـۥــمطور 』*  
> دائــمــاً فــي أمــان وخـدمــة 💻
    `.trim();

    await conn.sendMessage(m.chat, { text: "*_جــارٍ إرســال قــســم الــبــرمجــة... ⏳💻_*" }, { quoted: m });

    await conn.sendMessage(m.chat, {
        image: { url: imageUrl },
        caption: messageText
    }, { quoted: m });

    await conn.sendMessage(m.chat, { react: { text: '💻', key: m.key } });
};

handler.command = /^قسم-برمجه$/i;
handler.tags = ["مطور"];
handler.help = ["قسم-برمجه"];

export default handler;