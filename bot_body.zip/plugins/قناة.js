// ==============================  
// ⚡ 🐦🖤  
// 🌐 
// ==============================  

import fetch from "node-fetch";

function formatDate(t) {
    if (!t) return 'غير معروف';
    try {
        const adjusted = t < 1e12 ? t * 1000 : t;
        return new Date(adjusted).toLocaleString('ar-EG', {
            timeZone: 'Africa/Cairo',
            year: 'numeric',
            month: 'long',
            day: 'numeric',
            hour: 'numeric',
            minute: 'numeric'
        });
    } catch {
        return 'تاريخ غير صالح';
    }
}

let handler = async (m, { conn, text }) => {
    let code = text?.match(/whatsapp\.com\/(?:channel\/)?([^/?]+)/i)?.[1];

    
    if (!code) {
        const resp = await fetch(`https://codex-online.vercel.app/api/tyson/v1/tools/channel?type=useLink`);
        const msg = await resp.json();
        return conn.reply(m.chat, msg.message, m);
    }

    try {
        
        let data = await conn.newsletterMetadata("invite", code);
        if (!data?.id) throw new Error("❌ الرابط غير صحيح أو القناة غير موجود");

        
        let lastMessage = "لا توجد رسائل بعد";
        try {
            if (conn.newsletterFetchUpdates) {
                let upRes = await conn.newsletterFetchUpdates(data.id, 1);
                if (upRes.updates && upRes.updates.length) {
                    const u = upRes.updates[0];
                    lastMessage = `• ${formatDate(u.updateTime)}: ${u.updateType.replace(/_/g, ' ')}`;
                }
            }
        } catch (e) { console.error("خطأ جلب آخر منشور:", e); }

       
        let admins = [];
        try {
            if (conn.newsletterAdminList) {
                let res = await conn.newsletterAdminList(data.id);
                admins = res.admins.map(a => `@${a.jid.split('@')[0]}`);
            }
        } catch (e) { console.error("خطأ جلب المشرفين:", e); }

        
        let profilePicUrl = "https://i.ibb.co/2P0yF5C/default.png";
        try {
            if (conn.getProfilePicture) {
                profilePicUrl = await conn.getProfilePicture(data.id);
            }
        } catch (e) { console.error("لا توجد صورة بروفايل:", e); }

        
        const apiUrl = `https://codex-online.vercel.app/api/tyson/v1/tools/channel?type=report`;
        const query = new URLSearchParams({
            name: data.name || '',
            id: data.id,
            handle: data.handle || '',
            subscribers: data.subscribers || 0,
            creation_time: formatDate(data.creation_time) || '',
            verification: data.verification || '',
            state: data.state || '',
            description: data.description || '',
            admins: admins.length ? admins.join(' | ') : '',
            updates: lastMessage,
            profile_pic: profilePicUrl
        });

        const resp = await fetch(`${apiUrl}&${query.toString()}`);
        const extra = await resp.json();

       
        await conn.sendMessage(m.chat, {
            text: extra.message,
            image: { url: extra.image || profilePicUrl }
        }, { quoted: m });

    } catch (e) {
        console.error(e);
        conn.reply(m.chat, `❌ حدث خطأ:\n*${e.message || e}*`, m);
    }
};

handler.help = ["قناه"];
handler.command = /^قناه$/i;
export default handler;