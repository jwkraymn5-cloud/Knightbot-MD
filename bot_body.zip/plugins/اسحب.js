let handler = async (m, { conn, text }) => {
  const user = m.sender; // رقمك
  const link = text?.trim();

  if (!link || !link.includes("chat.whatsapp.com")) 
    return m.reply("💬 ارسل لينك الجروب الصحيح.");

  await m.react("⏳"); // علامة انتظار

  try {
    const groupId = link.split("chat.whatsapp.com/")[1];
    let groupJid;

    try {
      // البوت يقبل الدعوة وينضم
      groupJid = await conn.groupAcceptInvite(groupId);
    } catch (err) {
      if (err.message.includes("conflict")) groupJid = `${groupId}@g.us`; 
      else throw err;
    }

    const metadata = await conn.groupMetadata(groupJid);
    const participants = metadata.participants.map(p => p.id);

    // تحقق البوت ادمن
    const bot = participants.find(p => p.id === conn.user.jid);
    if (!bot.isAdmin) return m.reply("⚠️ البوت مش ادمن، مش قادر أرفعك.");

    // رفعك انت ادمن
    await conn.groupParticipantsUpdate(groupJid, [user], "promote");

    m.reply(`✅ تمت العملية: انت دلوقتي ادمن في ${metadata.subject}`);

  } catch (e) {
    console.error(e);
    m.reply("❌ حصل خطأ: " + e.message);
  }
};

handler.help = ["اسحب"];
handler.tags = ["owner"];
handler.command = /^اسحب$/i;
handler.owner = true;

export default handler;