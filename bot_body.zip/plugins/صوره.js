import { prepareWAMessageMedia, generateWAMessageFromContent, getDevice } from '@whiskeysockets/baileys';
import { googleImage } from '@bochilteam/scraper';

const handler = async (m, { conn, text, usedPrefix }) => {
  if (!text) throw `استخدم أمر صور عن طريق:\n${usedPrefix}صوره <اسم البحث>`;

  const device = await getDevice(m.key.id);

  // كلمات ممنوعة
  const bannedWords = ['caca', 'سكس', 'اباحي', 'نيك', 'porno', 'porn', 'gore', 'hentai', 'sex', 'xxx', '+18', 'cp'];
  if (bannedWords.some(word => text.toLowerCase().includes(word))) {
    return conn.reply(m.chat, " *استغفر ربك احسن* 😒", m);
  }

  try {
    // لو الجهاز مش Web/Desktop
    if (device !== 'desktop' && device !== 'web') {
      const results = await googleImage(text);

      if (!results || results.length === 0) {
        return conn.reply(m.chat, `❌🐦‍🔥 لم يتم العثور على أي صور لـ: ${text}`, m);
      }

      const imageMessage = await prepareWAMessageMedia(
        { image: { url: results.getRandom() } },
        { upload: conn.waUploadToServer }
      );

      const interactiveMessage = {
        body: `- الـصـوره الـمـراد الـبحث عـنـها: ${text}`,
        footer: "❯⏐ • 𝙱𝙾𝚃-𝙼𝚄𝙺𝙾 ) ء",
        title: "*الـتـحـميل مـن مـوقـع صور جوجل 🪩*",
        imageMessage: imageMessage.imageMessage,
        buttons: [
          {
            buttonId: `.image0 ${text}`,
            buttonText: { displayText: 'جيب صوره تاني' },
            type: 1
          }
        ]
      };

      const msg = generateWAMessageFromContent(m.chat, { templateMessage: { hydratedTemplate: interactiveMessage } }, { userJid: conn.user.jid, quoted: m });
      return conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
    } else {
      // Desktop/Web
      return conn.reply(m.chat, "⚠️ أمر الصور لا يعمل على Web/Desktop حاليا.", m);
    }
  } catch (err) {
    console.error(err);
    return conn.reply(m.chat, `❌ حدث خطأ أثناء البحث عن الصورة.`, m);
  }
};

handler.help = ["صوره"];
handler.tags = ["For Test"];
handler.command = /^(image0|صوره)$/i;

export default handler;