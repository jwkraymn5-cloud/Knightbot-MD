import { default: makeWASocket, useSingleFileAuthState, fetchLatestBaileysVersion, prepareWAMessageMedia, generateWAMessageFromContent } from '@whiskeysockets/baileys';
import P from 'pino';
import Parser from 'rss-parser';
const parser = new Parser();

const handlerNews = async (m, { conn }) => {
    try {
        // تفاعل أولي
        await conn.sendMessage(m.chat, { react: { text: "📈", key: m.key } });

        // جلب آخر 5 أخبار من RSS
        const feed = await parser.parseURL('https://www.alarabiya.net/.mrss/ar');
        const articles = feed.items.slice(0, 5);

        if (!articles.length) {
            await conn.sendMessage(m.chat, { text: "❌ لم أتمكن من العثور على أخبار." }, { quoted: m });
            return;
        }

        // نص الرسالة
        let newsText = "📰 *آخر الأخبار:*\n\n";
        articles.forEach((a, i) => {
            newsText += `*${i + 1}.* ${a.title}\n${a.link}\n\n`;
        });

        // تصميم الرسالة الاحترافي
        const dataMessage = `
╔═══❖•🔥•❖═══╗
        📰 𝐴𝐵𝐷𝑂 𝐁𝐎𝐓 📰
╚═══❖•🔥•❖═══╝

${newsText.trim()}

ـ〆⚡︱ 𝐴𝐵𝐷𝑂 ︱⚡〆ـ
        `.trim();

        // إرسال ✅ بعد جلب الأخبار
        await conn.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
        await conn.sendMessage(m.chat, { text: dataMessage }, { quoted: m });

    } catch (e) {
        console.error(e);
        await conn.sendMessage(m.chat, { text: "❌ حدث خطأ أثناء جلب الأخبار." }, { quoted: m });
    }
};

handlerNews.command = /^أخبار$/i;
export default handlerNews;