/*
أمر الترجمة لجميع اللغات 🌍
By: كيمو و لولو
*/

import axios from "axios";

let handler = async (m, { conn }) => {
  if (!m.quoted || !m.quoted.text) {
    return m.reply("💬 يا حب، لازم ترد على رسالة فيها نص وتكتب .ترجمة");
  }

  const textToTranslate = m.quoted.text.trim();

  try {
    // طلب من Google Translate API
    const res = await axios.get(
      `https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=ar&dt=t&q=${encodeURIComponent(
        textToTranslate
      )}`
    );

    const detectedLang = res.data?.[2] || "unknown";
    const translatedText = res.data?.[0]?.map((x) => x[0]).join("") || "";

    // لو الترجمة فاضية
    if (!translatedText) {
      return m.reply("❌ مفيش ترجمة يا حب، جرب تاني.");
    }

    // لو النص أصلاً بالعربي، ترجم لإنجليزي
    if (detectedLang === "ar") {
      const res2 = await axios.get(
        `https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=en&dt=t&q=${encodeURIComponent(
          textToTranslate
        )}`
      );

      const translatedText2 = res2.data?.[0]?.map((x) => x[0]).join("") || "";
      return conn.sendMessage(
        m.chat,
        {
          text: `🌍 *الترجمة (${res2.data?.[2] || "ar"} → en):*\n${translatedText2}`,
        },
        { quoted: m }
      );
    }

    // لو النص بلغة تانية، ترجم لعربي
    return conn.sendMessage(
      m.chat,
      {
        text: `🌍 *الترجمة (${detectedLang} → ar):*\n${translatedText}`,
      },
      { quoted: m }
    );
  } catch (err) {
    console.error("Translation Error:", err);
    m.reply("⚠️ حصل خطأ أثناء الترجمة يا حب.");
  }
};

handler.command = /^ترجمة$/i;
export default handler;