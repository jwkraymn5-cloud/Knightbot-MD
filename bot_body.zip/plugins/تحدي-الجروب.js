let handlerChallenge = async (m, { conn }) => {
    try {
        if (!m.isGroup) return; // التأكد أنه جروب

        // قائمة تحديات موسعة مع أزرار
        const challenges = [
            {
                text: "🎯 اختر رقم من 1 إلى 10، الرقم الصحيح سيعلنه البوت لاحقًا!",
                buttons: [
                    { buttonId: '1', buttonText: { displayText: '1️⃣' }, type: 1 },
                    { buttonId: '2', buttonText: { displayText: '2️⃣' }, type: 1 },
                    { buttonId: '3', buttonText: { displayText: '3️⃣' }, type: 1 },
                    { buttonId: '4', buttonText: { displayText: '4️⃣' }, type: 1 }
                ]
            },
            {
                text: "🤔 هل تحب القهوة أم الشاي؟",
                buttons: [
                    { buttonId: 'coffee', buttonText: { displayText: '☕ قهوة' }, type: 1 },
                    { buttonId: 'tea', buttonText: { displayText: '🍵 شاي' }, type: 1 }
                ]
            },
            {
                text: "📝 اختر كلمة اليوم:",
                buttons: [
                    { buttonId: 'نجاح', buttonText: { displayText: 'نجاح' }, type: 1 },
                    { buttonId: 'سعادة', buttonText: { displayText: 'سعادة' }, type: 1 },
                    { buttonId: 'مرح', buttonText: { displayText: 'مرح' }, type: 1 }
                ]
            },
            {
                text: "⚡ هل ستشارك في التحدي؟",
                buttons: [
                    { buttonId: 'yes', buttonText: { displayText: '✅ نعم' }, type: 1 },
                    { buttonId: 'no', buttonText: { displayText: '❌ لا' }, type: 1 }
                ]
            },
            {
                text: "🎲 رمي نرد: اختر رقم من 1 إلى 6",
                buttons: [
                    { buttonId: '1', buttonText: { displayText: '1️⃣' }, type: 1 },
                    { buttonId: '2', buttonText: { displayText: '2️⃣' }, type: 1 },
                    { buttonId: '3', buttonText: { displayText: '3️⃣' }, type: 1 },
                    { buttonId: '4', buttonText: { displayText: '4️⃣' }, type: 1 },
                    { buttonId: '5', buttonText: { displayText: '5️⃣' }, type: 1 },
                    { buttonId: '6', buttonText: { displayText: '6️⃣' }, type: 1 }
                ]
            },
            {
                text: "🌟 شارك حقيقة غريبة عن نفسك",
                buttons: [
                    { buttonId: 'حقيقة1', buttonText: { displayText: '✅ شارك' }, type: 1 },
                    { buttonId: 'حقيقة2', buttonText: { displayText: '❌ لا أريد' }, type: 1 }
                ]
            },
            {
                text: "🏆 من تعتقد أنه أكثر عضو نشيط؟",
                buttons: [
                    { buttonId: 'عضو1', buttonText: { displayText: '👤 عضو 1' }, type: 1 },
                    { buttonId: 'عضو2', buttonText: { displayText: '👤 عضو 2' }, type: 1 },
                    { buttonId: 'عضو3', buttonText: { displayText: '👤 عضو 3' }, type: 1 }
                ]
            },
            {
                text: "🎵 حاول غناء بداية أغنية مشهورة",
                buttons: [
                    { buttonId: 'ابدأ', buttonText: { displayText: '🎤 أبدأ' }, type: 1 },
                    { buttonId: 'توقف', buttonText: { displayText: '⏹️ توقف' }, type: 1 }
                ]
            },
            {
                text: "🕹️ اختر لعبة سريعة للجروب ولعبها خلال 5 دقائق",
                buttons: [
                    { buttonId: 'لعبة1', buttonText: { displayText: '🎮 لعبة 1' }, type: 1 },
                    { buttonId: 'لعبة2', buttonText: { displayText: '🎮 لعبة 2' }, type: 1 },
                    { buttonId: 'لعبة3', buttonText: { displayText: '🎮 لعبة 3' }, type: 1 }
                ]
            },
            {
                text: "🤹‍♂️ تحدي توازن: ضع أي شيء على رأسك وصور نفسك!",
                buttons: [
                    { buttonId: 'بدأ', buttonText: { displayText: '✅ بدأت' }, type: 1 },
                    { buttonId: 'توقف', buttonText: { displayText: '❌ توقفت' }, type: 1 }
                ]
            }
        ];

        // اختيار تحدي عشوائي
        const challenge = challenges[Math.floor(Math.random() * challenges.length)];

        // تصميم الرسالة الاحترافي
        const message = `
╔═══❖•🔥•❖═══╗
       🏆 𝐴𝐵𝐷𝑂 𝐁𝐎𝐓 🏆
╚═══❖•🔥•❖═══╝

📢 *تحدي الجروب:*
${challenge.text}

ـ〆⚡︱ 𝐴𝐵𝐷𝑂 ︱⚡〆ـ
        `.trim();

        await conn.sendMessage(
            m.chat,
            {
                text: message,
                buttons: challenge.buttons,
                headerType: 1
            },
            { quoted: m }
        );

    } catch (e) {
        console.error(e);
        await conn.sendMessage(m.chat, { text: "❌ حدث خطأ أثناء إرسال التحدي.", quoted: m });
    }
};

handlerChallenge.command = /^تحدي_الجروب$/i;
export default handlerChallenge;