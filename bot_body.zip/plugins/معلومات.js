let handler = async (m, { conn }) => {

    let group = m.chat
    let groupMetadata = await conn.groupMetadata(group)

    let groupName = groupMetadata.subject
    let groupId = groupMetadata.id
    let owner = groupMetadata.owner || groupMetadata.subjectOwner
    let participants = groupMetadata.participants.length
    let creation = groupMetadata.creation * 1000 // ← تصحيح التاريخ
    let desc = groupMetadata.desc || "لا يوجد وصف للمجموعة"

    // تنسيق التاريخ والوقت
    let formattedDate = new Date(creation).toLocaleString('ar-EG', {
        weekday: 'long',
        year: 'numeric',
        month: 'long',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit'
    })

    let textInfo = `
📌 *مـعـلـومـات الـمـجـمـوعـة*

👥 *الاسم:* ${groupName}
🆔 *المعرف:* ${groupId}
👑 *المالك:* ${owner ? '@' + owner.split('@')[0] : 'غير معروف'}
👤 *عدد الاعضاء:* ${participants}

📝 *وصف المجموعة:*
${desc}

⏳ *تاريخ الإنشاء:* ${formattedDate}
    `.trim()

    await conn.reply(m.chat, textInfo, m, {
        mentions: [owner]
    })
}

handler.help = ['info', 'معلومات']
handler.tags = ['group']
handler.command = ['معلومات','info','groupinfo']
handler.group = true

export default handler