/*
أمر الوقت ⏰ بدون API
By: كيمو و لولو
*/

import moment from "moment-timezone";

let handler = async (m, { conn, args }) => {
  if (!args[0]) return m.reply("💬 يا حب، اكتب اسم الدولة بعد الأمر.\nمثال:\n.الوقت مصر");

  const chatId = m.chat;
  const query = args.join(" ").toLowerCase();

  // خريطة الدول/المدن → timezone
  const TZ_MAP = {
    "مصر": "Africa/Cairo",
    "egypt": "Africa/Cairo",
    "السعودية": "Asia/Riyadh",
    "ksa": "Asia/Riyadh",
    "الامارات": "Asia/Dubai",
    "uae": "Asia/Dubai",
    "تونس": "Africa/Tunis",
    "المغرب": "Africa/Casablanca",
    "الجزائر": "Africa/Algiers",
    "العراق": "Asia/Baghdad",
    "سوريا": "Asia/Damascus",
    "لبنان": "Asia/Beirut",
    "الاردن": "Asia/Amman",
    "تركيا": "Europe/Istanbul",
    "فلسطين": "Asia/Gaza",
    "امريكا": "America/New_York",
    "usa": "America/New_York",
    "اليابان": "Asia/Tokyo",
    "الصين": "Asia/Shanghai",
    "فرنسا": "Europe/Paris",
    "المانيا": "Europe/Berlin",
    "بريطانيا": "Europe/London"
  };

  const tz = TZ_MAP[query] || query;

  try {
    const time = moment().tz(tz);
    if (!time.isValid()) throw new Error("Invalid timezone");

    const formattedDate = time.format("DD/MM/YYYY");
    const formattedTime = time.format("HH:mm:ss");

    const replyText = [
      `🕓 *الوقت الآن في* ${query}`,
      `📅 التاريخ: ${formattedDate}`,
      `⏰ الوقت: ${formattedTime}`
    ].join("\n");

    await conn.sendMessage(chatId, { text: replyText }, { quoted: m });
  } catch (err) {
    console.error("time error:", err.message);
    return m.reply("⚠️ يا حب، مافيش وقت معروف للاسم ده. جرب تكتب: مصر، السعودية، Asia/Cairo...");
  }
};

handler.help = ["الوقت <الدولة>"];
handler.tags = ["tools"];
handler.command = /^الوقت$/i;

export default handler;